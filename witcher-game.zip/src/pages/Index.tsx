import WitcherGame from '@/components/WitcherGame';

const Index = () => {
  return <WitcherGame />;
};

export default Index;
