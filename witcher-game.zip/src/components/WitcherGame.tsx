import { useRef, useEffect, useCallback, useState } from 'react';
import { Keys } from '@/game/types';
import { createInitialState, update } from '@/game/engine';
import {
  render, drawTitleScreen, drawGameOver, drawGameWon,
  drawIntroCrawl, drawDialogue, drawCutscene, drawEnding,
} from '@/game/renderer';
import { introCrawl, levelNpcs, cutsceneTriggers, endingLines } from '@/game/story';

const CANVAS_W = 640;
const CANVAS_H = 480;

const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile('ontouchstart' in window || window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);
  return isMobile;
};

const WitcherGame = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(createInitialState());
  const keysRef = useRef<Keys>({ left: false, right: false, up: false, attack: false, attackSilver: false });
  const rafRef = useRef<number>(0);
  const isMobile = useIsMobile();

  // Joystick state
  const joystickRef = useRef<{ active: boolean; startX: number; startY: number; currentX: number; currentY: number }>({
    active: false, startX: 0, startY: 0, currentX: 0, currentY: 0,
  });
  const [joystickPos, setJoystickPos] = useState({ dx: 0, dy: 0, active: false });
  const [attackPressed, setAttackPressed] = useState(false);
  const [silverPressed, setSilverPressed] = useState(false);
  const prevUpRef = useRef(false);

  // Intro typewriter timer
  const introTimerRef = useRef<number>(0);

  const advanceStory = useCallback(() => {
    const state = stateRef.current;

    if (state.storyPhase === 'intro') {
      // Check if all lines shown
      if (state.introLine >= introCrawl.length - 1 && state.introCharIndex >= introCrawl[introCrawl.length - 1].length) {
        state.storyPhase = 'playing';
      } else {
        // Skip to end
        state.introLine = introCrawl.length - 1;
        state.introCharIndex = introCrawl[introCrawl.length - 1].length;
      }
      return true;
    }

    if (state.storyPhase === 'dialogue') {
      const npc = levelNpcs.find(n => n.id === state.dialogueNpcId);
      if (npc) {
        if (state.dialogueLine < npc.dialogue.length - 1) {
          state.dialogueLine++;
        } else {
          // End dialogue
          state.npcsSpoken.push(npc.id);
          state.dialogueNpcId = null;
          state.storyPhase = 'playing';
          // Soldier gives potion
          if (npc.id === 'soldier') {
            state.player.health = Math.min(state.player.maxHealth, state.player.health + 2);
          }
          // Merchant gives orens
          if (npc.id === 'merchant') {
            state.score += 50;
          }
        }
      }
      return true;
    }

    if (state.storyPhase === 'cutscene') {
      const cs = cutsceneTriggers.find(c => c.id === state.cutsceneId);
      if (cs) {
        if (state.cutsceneLine < cs.lines.length - 1) {
          state.cutsceneLine++;
        } else {
          state.cutscenesSeen.push(cs.id);
          state.cutsceneId = null;
          state.storyPhase = 'playing';
        }
      }
      return true;
    }

    if (state.storyPhase === 'ending') {
      if (state.endingLine < endingLines.length - 1) {
        state.endingLine++;
      } else {
        // Restart game
        stateRef.current = createInitialState();
        stateRef.current.started = true;
        stateRef.current.storyPhase = 'intro';
      }
      return true;
    }

    return false;
  }, []);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    const state = stateRef.current;

    if (!state.started) {
      stateRef.current = createInitialState();
      stateRef.current.started = true;
      return;
    }

    if (state.gameOver) {
      stateRef.current = createInitialState();
      stateRef.current.started = true;
      return;
    }

    // Story advance
    if (state.storyPhase !== 'playing') {
      advanceStory();
      return;
    }

    switch (e.key) {
      case 'ArrowLeft': case 'a': keysRef.current.left = true; break;
      case 'ArrowRight': case 'd': keysRef.current.right = true; break;
      case 'ArrowUp': case 'w': keysRef.current.up = true; break;
      case ' ': keysRef.current.attack = true; e.preventDefault(); break;
      case 'q': case 'Q': keysRef.current.attackSilver = true; break;
    }
  }, [advanceStory]);

  const handleKeyUp = useCallback((e: KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowLeft': case 'a': keysRef.current.left = false; break;
      case 'ArrowRight': case 'd': keysRef.current.right = false; break;
      case 'ArrowUp': case 'w': keysRef.current.up = false; break;
      case ' ': keysRef.current.attack = false; break;
      case 'q': case 'Q': keysRef.current.attackSilver = false; break;
    }
  }, []);

  // Mobile: tap canvas for story/start
  const handleCanvasTap = useCallback(() => {
    const state = stateRef.current;
    if (!state.started) {
      stateRef.current = createInitialState();
      stateRef.current.started = true;
      return;
    }
    if (state.gameOver) {
      stateRef.current = createInitialState();
      stateRef.current.started = true;
      return;
    }
    if (state.storyPhase !== 'playing') {
      advanceStory();
    }
  }, [advanceStory]);

  // Joystick handlers
  const handleJoystickStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.touches[0];
    joystickRef.current = {
      active: true,
      startX: touch.clientX,
      startY: touch.clientY,
      currentX: touch.clientX,
      currentY: touch.clientY,
    };
    setJoystickPos({ dx: 0, dy: 0, active: true });
  }, []);

  const handleJoystickMove = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    if (!joystickRef.current.active) return;
    const touch = e.touches[0];
    joystickRef.current.currentX = touch.clientX;
    joystickRef.current.currentY = touch.clientY;

    const maxDist = 40;
    let dx = touch.clientX - joystickRef.current.startX;
    let dy = touch.clientY - joystickRef.current.startY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > maxDist) {
      dx = (dx / dist) * maxDist;
      dy = (dy / dist) * maxDist;
    }

    setJoystickPos({ dx, dy, active: true });

    const threshold = 12;
    keysRef.current.left = dx < -threshold;
    keysRef.current.right = dx > threshold;

    const isUp = dy < -threshold;
    if (isUp && !prevUpRef.current) {
      keysRef.current.up = true;
      requestAnimationFrame(() => { keysRef.current.up = false; });
    }
    prevUpRef.current = isUp;
  }, []);

  const handleJoystickEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    joystickRef.current.active = false;
    setJoystickPos({ dx: 0, dy: 0, active: false });
    keysRef.current.left = false;
    keysRef.current.right = false;
    keysRef.current.up = false;
  }, []);

  // Iron attack handlers
  const handleAttackStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    keysRef.current.attack = true;
    setAttackPressed(true);
  }, []);

  const handleAttackEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    keysRef.current.attack = false;
    setAttackPressed(false);
  }, []);

  // Silver attack handlers
  const handleSilverStart = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    keysRef.current.attackSilver = true;
    setSilverPressed(true);
  }, []);

  const handleSilverEnd = useCallback((e: React.TouchEvent) => {
    e.preventDefault();
    keysRef.current.attackSilver = false;
    setSilverPressed(false);
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyDown, handleKeyUp]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      const state = stateRef.current;

      if (!state.started) {
        drawTitleScreen(ctx, CANVAS_W, CANVAS_H);
      } else if (state.storyPhase === 'intro') {
        // Typewriter effect
        introTimerRef.current++;
        if (introTimerRef.current % 2 === 0) {
          const line = introCrawl[state.introLine];
          if (line && state.introCharIndex < line.length) {
            state.introCharIndex++;
          } else if (state.introLine < introCrawl.length - 1) {
            state.introLine++;
            state.introCharIndex = 0;
          }
        }
        drawIntroCrawl(ctx, CANVAS_W, CANVAS_H, state.introLine, state.introCharIndex);
      } else if (state.storyPhase === 'ending') {
        drawEnding(ctx, CANVAS_W, CANVAS_H, state.endingLine, state.score);
      } else {
        // Playing, dialogue, cutscene all render the game
        update(state, keysRef.current, CANVAS_W, CANVAS_H);
        render(ctx, state, CANVAS_W, CANVAS_H);

        if (state.gameOver) {
          drawGameOver(ctx, CANVAS_W, CANVAS_H, state.score);
        }

        // Overlay dialogue/cutscene on top of game
        if (state.storyPhase === 'dialogue' && state.dialogueNpcId) {
          drawDialogue(ctx, CANVAS_W, CANVAS_H, state.dialogueNpcId, state.dialogueLine);
        }
        if (state.storyPhase === 'cutscene' && state.cutsceneId) {
          drawCutscene(ctx, CANVAS_W, CANVAS_H, state.cutsceneId, state.cutsceneLine);
        }
      }

      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background gap-2 p-2 select-none overflow-hidden">
      <canvas
        ref={canvasRef}
        width={CANVAS_W}
        height={CANVAS_H}
        className="border border-border rounded-lg shadow-2xl w-full max-w-2xl"
        style={{ imageRendering: 'pixelated', aspectRatio: `${CANVAS_W}/${CANVAS_H}` }}
        onTouchStart={isMobile ? handleCanvasTap : undefined}
        tabIndex={0}
      />

      {isMobile && (
        <div className="w-full max-w-2xl flex justify-between items-end px-4 pt-2 pb-4"
             style={{ touchAction: 'none' }}>
          {/* Joystick */}
          <div
            className="relative rounded-full flex items-center justify-center"
            style={{
              width: 120,
              height: 120,
              background: 'radial-gradient(circle, hsl(var(--muted) / 0.4) 0%, hsl(var(--muted) / 0.15) 100%)',
              border: '2px solid hsl(var(--witcher-gold) / 0.3)',
            }}
            onTouchStart={handleJoystickStart}
            onTouchMove={handleJoystickMove}
            onTouchEnd={handleJoystickEnd}
          >
            <span className="absolute top-1 left-1/2 -translate-x-1/2 text-witcher-gold/50 text-[10px] font-mono">JUMP</span>
            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-witcher-gold/50 text-[10px] font-mono">◀</span>
            <span className="absolute right-2 top-1/2 -translate-y-1/2 text-witcher-gold/50 text-[10px] font-mono">▶</span>

            <div
              className="rounded-full transition-transform duration-75"
              style={{
                width: 44,
                height: 44,
                background: joystickPos.active
                  ? 'radial-gradient(circle, hsl(var(--witcher-gold) / 0.8), hsl(var(--witcher-gold) / 0.4))'
                  : 'radial-gradient(circle, hsl(var(--muted-foreground) / 0.5), hsl(var(--muted-foreground) / 0.2))',
                transform: `translate(${joystickPos.dx}px, ${joystickPos.dy}px)`,
                boxShadow: joystickPos.active ? '0 0 12px hsl(var(--witcher-gold) / 0.4)' : 'none',
              }}
            />
          </div>

          {/* Attack buttons */}
          <div className="flex flex-col gap-3 items-center">
            {/* Silver Sword - for monsters */}
            <div
              className="rounded-full flex flex-col items-center justify-center font-mono"
              style={{
                width: 72,
                height: 72,
                background: silverPressed
                  ? 'radial-gradient(circle, #c8ccd8cc, #8090a880)'
                  : 'radial-gradient(circle, #c8ccd840, #60708020)',
                border: `2px solid ${silverPressed ? '#c8ccd8aa' : '#c8ccd840'}`,
                boxShadow: silverPressed ? '0 0 16px #c8ccd860' : 'none',
                touchAction: 'none',
              }}
              onTouchStart={handleSilverStart}
              onTouchEnd={handleSilverEnd}
            >
              <span className="text-lg leading-none">🗡️</span>
              <span className="text-[8px] font-bold" style={{ color: silverPressed ? '#e0e4f0' : '#c8ccd890' }}>SILVER</span>
              <span className="text-[7px]" style={{ color: '#8090a870' }}>monsters</span>
            </div>

            {/* Iron Sword - for humans */}
            <div
              className="rounded-full flex flex-col items-center justify-center font-mono"
              style={{
                width: 72,
                height: 72,
                background: attackPressed
                  ? 'radial-gradient(circle, #8a7060cc, #5a403080)'
                  : 'radial-gradient(circle, #8a706040, #5a403020)',
                border: `2px solid ${attackPressed ? '#aa9070aa' : '#8a706040'}`,
                boxShadow: attackPressed ? '0 0 16px #8a706060' : 'none',
                touchAction: 'none',
              }}
              onTouchStart={handleAttackStart}
              onTouchEnd={handleAttackEnd}
            >
              <span className="text-lg leading-none">⚔️</span>
              <span className="text-[8px] font-bold" style={{ color: attackPressed ? '#daa520' : '#aa907090' }}>IRON</span>
              <span className="text-[7px]" style={{ color: '#8a706070' }}>humans</span>
            </div>
          </div>
        </div>
      )}

      {!isMobile && (
        <div className="text-muted-foreground text-xs font-mono text-center max-w-md">
          <span className="text-witcher-gold">ARROWS/WASD</span> Move & Jump · <span className="text-witcher-gold">SPACE</span> Iron Sword (humans) · <span className="text-witcher-gold">Q</span> Silver Sword (monsters)
        </div>
      )}
    </div>
  );
};

export default WitcherGame;
