export interface StoryLine {
  speaker?: string;
  text: string;
}

export interface NpcData {
  id: string;
  name: string;
  x: number;
  y: number;
  type: 'merchant' | 'soldier' | 'sorceress';
  dialogue: DialogueNode[];
  spoken: boolean;
}

export interface DialogueNode {
  speaker: string;
  text: string;
  choices?: { text: string; nextIndex: number }[];
}

export interface CutsceneTrigger {
  x: number;
  id: string;
  triggered: boolean;
  lines: StoryLine[];
}

// ====== INTRO CRAWL ======
export const introCrawl: string[] = [
  "The Continent, 1272.",
  "",
  "A village on the outskirts of Velen has been",
  "plagued by monsters emerging from ancient ruins",
  "beneath the earth.",
  "",
  "The villagers pooled their last orens to post",
  "a contract on the notice board:",
  "",
  "\"WITCHER NEEDED — Dungeon beneath the old keep.",
  " Drowners and ghouls. Pay on completion.\"",
  "",
  "Geralt of Rivia, the White Wolf, has answered",
  "the call. Armed with his silver sword and",
  "witcher senses, he descends into the darkness...",
];

// ====== NPC DATA ======
export const levelNpcs: NpcData[] = [
  {
    id: 'soldier',
    name: 'Wounded Soldier',
    x: 120,
    y: 380,
    type: 'soldier',
    spoken: false,
    dialogue: [
      { speaker: 'Wounded Soldier', text: "Witcher... thank the gods. I went in with five men. I'm the only one left." },
      { speaker: 'Geralt', text: "What happened down here?" },
      { speaker: 'Wounded Soldier', text: "Drowners... dozens of them. And something bigger, deeper in. We heard it roar." },
      { speaker: 'Geralt', text: "Sounds like a contract worth taking. Get yourself out." },
      { speaker: 'Wounded Soldier', text: "Take this potion — found it on one of my men. He won't need it anymore." },
    ],
  },
  {
    id: 'merchant',
    name: 'Trapped Merchant',
    x: 1750,
    y: 380,
    type: 'merchant',
    spoken: false,
    dialogue: [
      { speaker: 'Trapped Merchant', text: "Don't kill me! I'm no monster! Got trapped down here looking for treasure." },
      { speaker: 'Geralt', text: "Treasure hunting in a monster-infested dungeon. Smart." },
      { speaker: 'Trapped Merchant', text: "Look, I know these tunnels. Ahead there's a chasm — use the old bridges." },
      { speaker: 'Geralt', text: "Anything else I should know?" },
      { speaker: 'Trapped Merchant', text: "The creatures... they're guarding something. Some kind of relic. Glows blue." },
      { speaker: 'Geralt', text: "A Place of Power, maybe. I'll handle it." },
    ],
  },
  {
    id: 'sorceress',
    name: 'Keira Metz',
    x: 2950,
    y: 380,
    type: 'sorceress',
    spoken: false,
    dialogue: [
      { speaker: 'Keira Metz', text: "Geralt! What a pleasant surprise in this charming locale." },
      { speaker: 'Geralt', text: "Keira. What are you doing in a dungeon full of drowners?" },
      { speaker: 'Keira Metz', text: "Research, dear. There's an artifact at the end — a Convergence Stone." },
      { speaker: 'Geralt', text: "Let me guess — you need me to clear the way." },
      { speaker: 'Keira Metz', text: "How perceptive. The final chamber is just ahead. Be careful — I sense something powerful." },
      { speaker: 'Geralt', text: "When am I not careful?" },
      { speaker: 'Keira Metz', text: "...Do you really want me to answer that?" },
    ],
  },
];

// ====== CUTSCENE TRIGGERS (by x position) ======
export const cutsceneTriggers: CutsceneTrigger[] = [
  {
    x: 1150,
    id: 'entering_deep',
    triggered: false,
    lines: [
      { text: "The air grows colder. Geralt's medallion" },
      { text: "trembles — a sign of powerful magic nearby." },
      { text: "" },
      { speaker: 'Geralt', text: "\"Medallion's humming. Something ahead.\"" },
    ],
  },
  {
    x: 2250,
    id: 'chasm',
    triggered: false,
    lines: [
      { text: "Deep below, the sound of rushing water echoes" },
      { text: "through the cavern. Ancient bridges span the void." },
      { text: "" },
      { speaker: 'Geralt', text: "\"The merchant wasn't lying. One wrong step...\"" },
    ],
  },
  {
    x: 3100,
    id: 'final_approach',
    triggered: false,
    lines: [
      { text: "The walls are covered in elven runes, pulsing" },
      { text: "with faint blue light. The source is close." },
      { text: "" },
      { speaker: 'Geralt', text: "\"Place of Power. Gotta be.\"" },
    ],
  },
];

// ====== ENDING ======
export const endingLines: StoryLine[] = [
  { text: "The last creature falls. Silence returns to the dungeon." },
  { text: "" },
  { text: "At the heart of the chamber, a Convergence Stone" },
  { text: "pulses with ancient energy." },
  { text: "" },
  { speaker: 'Geralt', text: "\"Should probably leave this for Keira.\"" },
  { speaker: 'Geralt', text: "\"...After I draw from it first.\"" },
  { text: "" },
  { text: "Geralt places his hand on the stone. Power surges" },
  { text: "through him — an ability point earned." },
  { text: "" },
  { text: "The contract is complete. Time to collect the pay." },
  { text: "" },
  { text: "THE END" },
];
