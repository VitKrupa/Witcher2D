import { Platform, Enemy, Pickup } from './types';

export interface LevelData {
  platforms: Platform[];
  enemies: Enemy[];
  pickups: Pickup[];
  playerStart: { x: number; y: number };
  width: number;
  height: number;
}

const makeEnemy = (x: number, y: number, type: 'drowner' | 'ghoul' | 'bandit' | 'deserter'): Enemy => ({
  pos: { x, y },
  vel: { x: 0, y: 0 },
  width: 28,
  height: 36,
  health: type === 'ghoul' ? 3 : type === 'deserter' ? 3 : 2,
  maxHealth: type === 'ghoul' ? 3 : type === 'deserter' ? 3 : 2,
  facing: -1,
  type,
  race: (type === 'bandit' || type === 'deserter') ? 'human' : 'monster',
  state: 'patrol',
  animFrame: 0,
  animTimer: 0,
  patrolDir: -1,
  patrolTimer: 120,
  attackCooldown: 0,
  deathTimer: 0,
});

// Prince of Persia style: vertical rooms connected by passages
// Canvas: 640x480. Each "room" is roughly one screen wide (600px) and uses full height.
// Multiple floors per room, ~60px per floor (player=40 + 20 headroom minimum).
// Ground floors, mid-floors, upper floors with ladders/stairs connecting them.

export const levels: LevelData[] = [
  {
    width: 3800,
    height: 900,
    playerStart: { x: 80, y: 340 },
    platforms: [
      // ========== ROOM 1: Entry Chamber (x: 0-600) ==========
      // Ground floor
      { x: 0, y: 420, width: 600, height: 80, type: 'stone' },
      // Left wall (floor to ceiling)
      { x: 0, y: 0, width: 20, height: 420, type: 'stone' },
      // Right wall with passage at ground level (gap at y: 340-420)
      { x: 580, y: 0, width: 20, height: 340, type: 'stone' },
      // Upper floor (walkway) - high enough: 420-280 = 140px clearance underneath
      { x: 40, y: 280, width: 250, height: 16, type: 'stone' },
      // Mid-level step to reach upper floor
      { x: 350, y: 350, width: 100, height: 16, type: 'stone' },
      { x: 200, y: 320, width: 80, height: 16, type: 'bridge' },
      // Top floor - 280-180=100px clearance
      { x: 300, y: 180, width: 200, height: 16, type: 'stone' },
      // Ceiling
      { x: 0, y: 0, width: 600, height: 16, type: 'stone' },

      // ========== ROOM 2: Spike Corridor (x: 600-1200) ==========
      // Ground with spike traps
      { x: 600, y: 420, width: 200, height: 80, type: 'stone' },
      { x: 800, y: 455, width: 80, height: 25, type: 'spike' },
      { x: 880, y: 420, width: 140, height: 80, type: 'stone' },
      { x: 1020, y: 455, width: 60, height: 25, type: 'spike' },
      { x: 1080, y: 420, width: 120, height: 80, type: 'stone' },
      // Upper passage (alt route over spikes) - 420-280=140px clearance
      { x: 620, y: 280, width: 120, height: 16, type: 'bridge' },
      { x: 780, y: 260, width: 100, height: 16, type: 'stone' },
      { x: 920, y: 280, width: 110, height: 16, type: 'bridge' },
      { x: 1060, y: 260, width: 100, height: 16, type: 'stone' },
      // Right wall with upper and lower passage
      { x: 1180, y: 0, width: 20, height: 200, type: 'stone' },
      { x: 1180, y: 300, width: 20, height: 120, type: 'stone' },
      // Ceiling
      { x: 600, y: 0, width: 600, height: 16, type: 'stone' },

      // ========== ROOM 3: Vertical Shaft (x: 1200-1700) ==========
      // Multi-level room - the heart of PoP style
      // Bottom pit with spikes
      { x: 1200, y: 460, width: 500, height: 40, type: 'stone' },
      { x: 1280, y: 445, width: 340, height: 25, type: 'spike' },
      // Floor 1 (entry level) - safe landing
      { x: 1200, y: 380, width: 180, height: 16, type: 'stone' },
      { x: 1500, y: 380, width: 180, height: 16, type: 'stone' },
      // Floor 2 - 380-300=80px clearance
      { x: 1300, y: 300, width: 200, height: 16, type: 'stone' },
      // Floor 3 - 300-220=80px clearance
      { x: 1200, y: 220, width: 160, height: 16, type: 'stone' },
      { x: 1440, y: 220, width: 160, height: 16, type: 'stone' },
      // Floor 4 (top) - 220-140=80px clearance
      { x: 1280, y: 140, width: 250, height: 16, type: 'stone' },
      // Left wall
      { x: 1200, y: 0, width: 20, height: 380, type: 'stone' },
      // Right wall with passage at floor 2 level
      { x: 1680, y: 0, width: 20, height: 240, type: 'stone' },
      { x: 1680, y: 340, width: 20, height: 160, type: 'stone' },
      // Ceiling
      { x: 1200, y: 0, width: 500, height: 16, type: 'stone' },

      // ========== ROOM 4: Guard Barracks (x: 1700-2300) ==========
      // Ground floor - large open room
      { x: 1700, y: 420, width: 600, height: 80, type: 'stone' },
      // Barracks platforms (bunks/shelves) - 420-320=100px clearance
      { x: 1720, y: 320, width: 100, height: 16, type: 'bridge' },
      { x: 1900, y: 310, width: 120, height: 16, type: 'stone' },
      { x: 2100, y: 320, width: 100, height: 16, type: 'bridge' },
      // Upper walkway - 310-210=100px clearance
      { x: 1800, y: 210, width: 300, height: 16, type: 'stone' },
      // Watch tower top - 210-120=90px clearance
      { x: 1900, y: 120, width: 100, height: 16, type: 'stone' },
      // Right wall
      { x: 2280, y: 0, width: 20, height: 340, type: 'stone' },
      // Ceiling
      { x: 1700, y: 0, width: 600, height: 16, type: 'stone' },

      // ========== ROOM 5: Dungeon Depths (x: 2300-2900) ==========
      // Descending room - enter from upper right of room 4
      { x: 2300, y: 420, width: 600, height: 80, type: 'stone' },
      // Staircase descending left to right
      { x: 2320, y: 340, width: 100, height: 16, type: 'stone' },
      { x: 2460, y: 300, width: 100, height: 16, type: 'bridge' },
      { x: 2600, y: 260, width: 100, height: 16, type: 'stone' },
      { x: 2740, y: 220, width: 100, height: 16, type: 'stone' },
      // Spike trap mid-room
      { x: 2500, y: 455, width: 100, height: 25, type: 'spike' },
      // Upper ledge
      { x: 2400, y: 180, width: 200, height: 16, type: 'stone' },
      // Right wall with passage
      { x: 2880, y: 0, width: 20, height: 340, type: 'stone' },
      // Ceiling
      { x: 2300, y: 0, width: 600, height: 16, type: 'stone' },

      // ========== ROOM 6: Final Chamber (x: 2900-3600) ==========
      // Grand room with multiple floors
      { x: 2900, y: 420, width: 700, height: 80, type: 'stone' },
      // Central pillar platforms
      { x: 2920, y: 350, width: 80, height: 16, type: 'stone' },
      { x: 3100, y: 340, width: 120, height: 16, type: 'stone' },
      { x: 3320, y: 350, width: 80, height: 16, type: 'stone' },
      { x: 3450, y: 330, width: 100, height: 16, type: 'stone' },
      // Upper walkway - 340-240=100px clearance
      { x: 3000, y: 240, width: 200, height: 16, type: 'stone' },
      { x: 3300, y: 250, width: 150, height: 16, type: 'bridge' },
      // Throne platform (top) - 240-150=90px clearance
      { x: 3150, y: 150, width: 200, height: 16, type: 'stone' },
      // Final spikes guarding exit
      { x: 3500, y: 455, width: 60, height: 25, type: 'spike' },
      // Right wall (exit)
      { x: 3580, y: 0, width: 20, height: 420, type: 'stone' },
      // Ceiling
      { x: 2900, y: 0, width: 700, height: 16, type: 'stone' },
    ],
    enemies: [
      // Room 1 - light intro
      makeEnemy(250, 380, 'bandit'),
      makeEnemy(150, 240, 'bandit'),

      // Room 2 - monsters in corridor
      makeEnemy(700, 380, 'drowner'),
      makeEnemy(950, 380, 'drowner'),
      makeEnemy(850, 220, 'ghoul'),

      // Room 3 - vertical shaft guardians
      makeEnemy(1350, 260, 'drowner'),
      makeEnemy(1500, 340, 'ghoul'),
      makeEnemy(1300, 180, 'deserter'),

      // Room 4 - barracks full of humans
      makeEnemy(1800, 380, 'bandit'),
      makeEnemy(1950, 380, 'deserter'),
      makeEnemy(2150, 380, 'bandit'),
      makeEnemy(1900, 270, 'deserter'),

      // Room 5 - dungeon mix
      makeEnemy(2400, 380, 'ghoul'),
      makeEnemy(2650, 380, 'drowner'),
      makeEnemy(2750, 180, 'deserter'),

      // Room 6 - final battle
      makeEnemy(3050, 380, 'ghoul'),
      makeEnemy(3200, 380, 'deserter'),
      makeEnemy(3350, 380, 'ghoul'),
      makeEnemy(3150, 200, 'bandit'),
      makeEnemy(3450, 380, 'deserter'),
    ],
    pickups: [
      // Room 1
      { x: 100, y: 260, type: 'potion', collected: false },
      { x: 400, y: 160, type: 'sign', collected: false },
      // Room 2
      { x: 850, y: 230, type: 'potion', collected: false },
      // Room 3
      { x: 1400, y: 120, type: 'potion', collected: false },
      { x: 1250, y: 200, type: 'sign', collected: false },
      // Room 4
      { x: 1950, y: 100, type: 'potion', collected: false },
      // Room 5
      { x: 2500, y: 160, type: 'potion', collected: false },
      { x: 2800, y: 200, type: 'sign', collected: false },
      // Room 6
      { x: 3200, y: 130, type: 'potion', collected: false },
      { x: 3400, y: 300, type: 'sign', collected: false },
    ],
  },
];
