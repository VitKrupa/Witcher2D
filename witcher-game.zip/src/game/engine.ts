import { GameState, Keys, Player, Enemy, Particle } from './types';
import { levels } from './levels';
import { levelNpcs, cutsceneTriggers } from './story';

const GRAVITY = 0.5;
const PLAYER_SPEED = 2.5;
const JUMP_FORCE = -9.8;
const ATTACK_DURATION = 18;
const ATTACK_RANGE = 36;

export function createInitialState(): GameState {
  const level = levels[0];
  return {
    player: {
      pos: { ...level.playerStart },
      vel: { x: 0, y: 0 },
      width: 20,
      height: 40,
      health: 5,
      maxHealth: 5,
      facing: 1,
      grounded: false,
      attacking: false,
      attackTimer: 0,
      activeSword: 'silver',
      invulnerable: 0,
      animFrame: 0,
      animTimer: 0,
      state: 'idle',
    },
    enemies: level.enemies.map(e => ({ ...e, pos: { ...e.pos }, vel: { ...e.vel } })),
    platforms: [...level.platforms],
    pickups: level.pickups.map(p => ({ ...p })),
    particles: [],
    camera: { x: 0, y: 0 },
    score: 0,
    level: 0,
    gameOver: false,
    gameWon: false,
    started: false,
    storyPhase: 'intro',
    introLine: 0,
    introCharIndex: 0,
    introTimer: 0,
    dialogueNpcId: null,
    dialogueLine: 0,
    cutsceneId: null,
    cutsceneLine: 0,
    endingLine: 0,
    npcsSpoken: [],
    cutscenesSeen: [],
  };
}

export function update(state: GameState, keys: Keys, canvasW: number, canvasH: number): GameState {
  if (!state.started || state.gameOver || state.gameWon) return state;
  if (state.storyPhase !== 'playing') return state;

  const p = state.player;

  // Player input
  if (p.state !== 'dead') {
    if (keys.left) {
      p.vel.x = -PLAYER_SPEED;
      p.facing = -1;
    } else if (keys.right) {
      p.vel.x = PLAYER_SPEED;
      p.facing = 1;
    } else {
      p.vel.x *= 0.7;
      if (Math.abs(p.vel.x) < 0.1) p.vel.x = 0;
    }

    if (keys.up && p.grounded) {
      p.vel.y = JUMP_FORCE;
      p.grounded = false;
    }

    // Iron sword attack (Space / left attack button)
    if (keys.attack && !p.attacking && p.grounded) {
      p.attacking = true;
      p.attackTimer = ATTACK_DURATION;
      p.activeSword = 'iron';
      spawnParticles(state, p.pos.x + p.facing * 20, p.pos.y + 10, 3, '#8a8a8a');
    }

    // Silver sword attack (Q / right attack button)
    if (keys.attackSilver && !p.attacking && p.grounded) {
      p.attacking = true;
      p.attackTimer = ATTACK_DURATION;
      p.activeSword = 'silver';
      spawnParticles(state, p.pos.x + p.facing * 20, p.pos.y + 10, 3, '#c0c8e0');
    }
  }

  // Gravity
  p.vel.y += GRAVITY;
  p.pos.x += p.vel.x;
  p.pos.y += p.vel.y;

  // Attack timer
  if (p.attacking) {
    p.attackTimer--;
    if (p.attackTimer <= 0) p.attacking = false;
  }

  // Invulnerability
  if (p.invulnerable > 0) p.invulnerable--;

  // Animation
  p.animTimer++;
  updatePlayerState(p);

  // Platform collisions for player
  p.grounded = false;
  for (const plat of state.platforms) {
    if (plat.type === 'spike') {
      if (rectOverlap(p.pos.x, p.pos.y, p.width, p.height, plat.x, plat.y, plat.width, plat.height)) {
        if (p.invulnerable <= 0) {
          p.health -= 2;
          p.invulnerable = 60;
          p.vel.y = -6;
          spawnParticles(state, p.pos.x + p.width / 2, p.pos.y + p.height, 8, '#8b0000');
        }
      }
      continue;
    }

    resolveCollision(p, plat);
  }

  // Enemies
  for (const e of state.enemies) {
    if (e.state === 'dead') {
      e.deathTimer--;
      continue;
    }

    // AI - only act if not hurt
    const dist = Math.abs((e.pos.x + e.width / 2) - (p.pos.x + p.width / 2));
    const dir = p.pos.x > e.pos.x ? 1 : -1;

    if (e.state === 'hurt') {
      // Recover from hurt after a short time
      if (e.attackCooldown <= 0) {
        e.state = 'patrol';
      }
    } else {
      // Check if there's a platform between enemy and player (line of sight)
      const hasLineOfSight = !hasPlatformBetween(state, e, p);

      if (dist < 200 && p.state !== 'dead' && hasLineOfSight) {
        e.state = 'chase';
        e.facing = dir as 1 | -1;
        e.vel.x = dir * (e.type === 'ghoul' ? 1.2 : 0.9);

        if (dist < 30) {
          e.state = 'attack';
          e.vel.x = 0;
          if (e.attackCooldown <= 0 && p.invulnerable <= 0) {
            p.health -= e.type === 'ghoul' ? 2 : 1;
            p.invulnerable = 45;
            p.vel.x = -dir * 4;
            p.vel.y = -3;
            e.attackCooldown = 40;
            spawnParticles(state, p.pos.x + p.width / 2, p.pos.y + 10, 5, '#8b0000');
          }
        }
      } else if (!hasLineOfSight) {
        e.state = 'patrol';
        e.patrolTimer--;
        if (e.patrolTimer <= 0) {
          e.patrolDir = (e.patrolDir * -1) as 1 | -1;
          e.facing = e.patrolDir;
          e.patrolTimer = 80 + Math.random() * 80;
        }
        e.vel.x = e.patrolDir * 0.5;
      } else {
        e.state = 'patrol';
        e.patrolTimer--;
        if (e.patrolTimer <= 0) {
          e.patrolDir = (e.patrolDir * -1) as 1 | -1;
          e.facing = e.patrolDir;
          e.patrolTimer = 80 + Math.random() * 80;
        }
        e.vel.x = e.patrolDir * 0.5;
      }
    }

    if (e.attackCooldown > 0) e.attackCooldown--;

    // Physics
    e.vel.y += GRAVITY;
    e.pos.x += e.vel.x;
    e.pos.y += e.vel.y;

    // Platform collisions for enemies (including spike death)
    for (const plat of state.platforms) {
      if (plat.type === 'spike') {
        if (rectOverlap(e.pos.x, e.pos.y, e.width, e.height, plat.x, plat.y, plat.width, plat.height)) {
          e.health = 0;
          e.state = 'dead';
          e.deathTimer = 30;
          state.score += e.type === 'ghoul' ? 50 : 30;
          spawnParticles(state, e.pos.x + e.width / 2, e.pos.y + e.height / 2, 12, '#8b0000');
        }
        continue;
      }
      resolveCollision(e, plat);
    }

    // Player attack hit
    if (p.attacking && p.attackTimer > 8 && p.attackTimer < 14) {
      const attackX = p.pos.x + (p.facing === 1 ? p.width : -ATTACK_RANGE);
      if (rectOverlap(attackX, p.pos.y, ATTACK_RANGE, p.height, e.pos.x, e.pos.y, e.width, e.height)) {
        // Correct sword does full damage, wrong sword does minimal
        const correctSword = (e.race === 'human' && p.activeSword === 'iron') ||
                             (e.race === 'monster' && p.activeSword === 'silver');
        const damage = correctSword ? 1 : 0.34;
        e.health -= damage;

        e.vel.x = p.facing * (correctSword ? 5 : 2);
        e.vel.y = correctSword ? -3 : -1;
        e.state = 'hurt';
        e.attackCooldown = 20;

        // Visual feedback: correct sword = blood, wrong = sparks
        if (correctSword) {
          spawnParticles(state, e.pos.x + e.width / 2, e.pos.y + 10, 6, e.race === 'human' ? '#8b0000' : '#2e5547');
        } else {
          spawnParticles(state, e.pos.x + e.width / 2, e.pos.y + 10, 4, '#aaaaaa');
        }

        if (e.health <= 0) {
          e.state = 'dead';
          e.deathTimer = 30;
          const scoreMap = { ghoul: 50, drowner: 30, bandit: 35, deserter: 45 };
          state.score += scoreMap[e.type] || 30;
          spawnParticles(state, e.pos.x + e.width / 2, e.pos.y + e.height / 2, 12,
            e.race === 'human' ? '#8b4513' : (e.type === 'ghoul' ? '#5c3a3a' : '#2e5547'));
        }
      }
    }
    // Enemy fall death
    if (e.pos.y > 550) {
      e.state = 'dead';
      e.health = 0;
      e.deathTimer = 0;
    }

    e.animTimer++;
  }

  // Pickups
  for (const pk of state.pickups) {
    if (pk.collected) continue;
    if (rectOverlap(p.pos.x, p.pos.y, p.width, p.height, pk.x - 8, pk.y - 8, 16, 16)) {
      pk.collected = true;
      if (pk.type === 'potion') {
        p.health = Math.min(p.maxHealth, p.health + 2);
        spawnParticles(state, pk.x, pk.y, 8, '#ffd700');
      } else {
        state.score += 100;
        spawnParticles(state, pk.x, pk.y, 10, '#4a90d9');
      }
    }
  }

  // Particles
  state.particles = state.particles.filter(part => {
    part.x += part.vx;
    part.y += part.vy;
    part.vy += 0.1;
    part.life--;
    return part.life > 0;
  });

  // Death
  if (p.health <= 0) {
    p.state = 'dead';
    p.health = 0;
    state.gameOver = true;
  }

  // Fall death
  if (p.pos.y > 550) {
    p.health = 0;
    p.state = 'dead';
    state.gameOver = true;
  }

  // Win condition → trigger ending story
  const allDead = state.enemies.every(e => e.state === 'dead');
  if (allDead && p.pos.x > levels[0].width - 100) {
    state.storyPhase = 'ending';
    state.endingLine = 0;
  }

  // NPC proximity check
  for (const npc of levelNpcs) {
    if (state.npcsSpoken.includes(npc.id)) continue;
    const dist = Math.abs(p.pos.x - npc.x);
    if (dist < 40) {
      state.storyPhase = 'dialogue';
      state.dialogueNpcId = npc.id;
      state.dialogueLine = 0;
    }
  }

  // Cutscene triggers
  for (const cs of cutsceneTriggers) {
    if (state.cutscenesSeen.includes(cs.id)) continue;
    if (p.pos.x > cs.x && p.pos.x < cs.x + 50) {
      state.storyPhase = 'cutscene';
      state.cutsceneId = cs.id;
      state.cutsceneLine = 0;
    }
  }

  // Camera
  const targetCamX = p.pos.x - canvasW / 2 + p.width / 2;
  const targetCamY = Math.min(0, p.pos.y - canvasH / 2);
  state.camera.x += (targetCamX - state.camera.x) * 0.08;
  state.camera.y += (targetCamY - state.camera.y) * 0.08;
  state.camera.x = Math.max(0, Math.min(state.camera.x, levels[0].width - canvasW));

  return state;
}

function updatePlayerState(p: Player) {
  if (p.attacking) {
    p.state = 'attack';
  } else if (!p.grounded && p.vel.y < 0) {
    p.state = 'jump';
  } else if (!p.grounded && p.vel.y > 0) {
    p.state = 'fall';
  } else if (Math.abs(p.vel.x) > 0.3) {
    p.state = 'run';
  } else {
    p.state = 'idle';
  }
}

function rectOverlap(ax: number, ay: number, aw: number, ah: number, bx: number, by: number, bw: number, bh: number): boolean {
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

function resolveCollision(entity: { pos: { x: number; y: number }; vel: { x: number; y: number }; width: number; height: number; grounded?: boolean }, plat: { x: number; y: number; width: number; height: number }) {
  if (!rectOverlap(entity.pos.x, entity.pos.y, entity.width, entity.height, plat.x, plat.y, plat.width, plat.height)) return;

  const overlapLeft = (entity.pos.x + entity.width) - plat.x;
  const overlapRight = (plat.x + plat.width) - entity.pos.x;
  const overlapTop = (entity.pos.y + entity.height) - plat.y;
  const overlapBottom = (plat.y + plat.height) - entity.pos.y;

  const minOverlap = Math.min(overlapLeft, overlapRight, overlapTop, overlapBottom);

  if (minOverlap === overlapTop && entity.vel.y >= 0) {
    entity.pos.y = plat.y - entity.height;
    entity.vel.y = 0;
    if ('grounded' in entity) entity.grounded = true;
  } else if (minOverlap === overlapBottom && entity.vel.y < 0) {
    entity.pos.y = plat.y + plat.height;
    entity.vel.y = 0;
  } else if (minOverlap === overlapLeft) {
    entity.pos.x = plat.x - entity.width;
    entity.vel.x = 0;
  } else if (minOverlap === overlapRight) {
    entity.pos.x = plat.x + plat.width;
    entity.vel.x = 0;
  }
}

function hasPlatformBetween(state: GameState, e: Enemy, p: Player): boolean {
  // Check if a solid platform separates them vertically
  const ex = e.pos.x + e.width / 2;
  const px = p.pos.x + p.width / 2;
  const minX = Math.min(ex, px);
  const maxX = Math.max(ex, px);
  const minY = Math.min(e.pos.y + e.height, p.pos.y + p.height);
  const maxY = Math.max(e.pos.y, p.pos.y);

  for (const plat of state.platforms) {
    if (plat.type === 'spike') continue;
    // Platform must overlap horizontally with both entities
    if (plat.x + plat.width < minX || plat.x > maxX) continue;
    // Platform must be between them vertically
    if (plat.y >= minY && plat.y + plat.height <= maxY + 10) {
      return true;
    }
    // Also check if platform top is between their feet
    if (plat.y > Math.min(e.pos.y + e.height, p.pos.y + p.height) - 5 &&
        plat.y < Math.max(e.pos.y + e.height, p.pos.y + p.height) - 5) {
      const heightDiff = Math.abs((e.pos.y + e.height) - (p.pos.y + p.height));
      if (heightDiff > 20) return true;
    }
  }
  return false;
}

function spawnParticles(state: GameState, x: number, y: number, count: number, color: string) {
  for (let i = 0; i < count; i++) {
    state.particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 4,
      vy: -Math.random() * 3 - 1,
      life: 20 + Math.random() * 15,
      maxLife: 35,
      color,
      size: 1.5 + Math.random() * 2,
    });
  }
}
