export interface Vector2 {
  x: number;
  y: number;
}

export interface Entity {
  pos: Vector2;
  vel: Vector2;
  width: number;
  height: number;
}

export interface Player extends Entity {
  health: number;
  maxHealth: number;
  facing: 1 | -1;
  grounded: boolean;
  attacking: boolean;
  attackTimer: number;
  activeSword: 'iron' | 'silver';
  invulnerable: number;
  animFrame: number;
  animTimer: number;
  state: 'idle' | 'run' | 'jump' | 'fall' | 'attack' | 'dead';
}

export interface Enemy extends Entity {
  health: number;
  maxHealth: number;
  facing: 1 | -1;
  type: 'drowner' | 'ghoul' | 'bandit' | 'deserter';
  race: 'monster' | 'human';
  state: 'idle' | 'patrol' | 'chase' | 'attack' | 'hurt' | 'dead';
  animFrame: number;
  animTimer: number;
  patrolDir: 1 | -1;
  patrolTimer: number;
  attackCooldown: number;
  deathTimer: number;
}

export interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'stone' | 'bridge' | 'spike';
}

export interface Pickup {
  x: number;
  y: number;
  type: 'potion' | 'sign';
  collected: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface GameState {
  player: Player;
  enemies: Enemy[];
  platforms: Platform[];
  pickups: Pickup[];
  particles: Particle[];
  camera: Vector2;
  score: number;
  level: number;
  gameOver: boolean;
  gameWon: boolean;
  started: boolean;
  // Story
  storyPhase: 'intro' | 'playing' | 'dialogue' | 'cutscene' | 'ending';
  introLine: number;
  introCharIndex: number;
  introTimer: number;
  dialogueNpcId: string | null;
  dialogueLine: number;
  cutsceneId: string | null;
  cutsceneLine: number;
  endingLine: number;
  npcsSpoken: string[];
  cutscenesSeen: string[];
}

export interface Keys {
  left: boolean;
  right: boolean;
  up: boolean;
  attack: boolean;
  attackSilver: boolean;
}
