import { GameState, Player, Enemy, Platform, Particle } from './types';
import { introCrawl, levelNpcs, cutsceneTriggers, endingLines, type StoryLine, type NpcData } from './story';

const COLORS = {
  bg: '#080c12',
  bgMid: '#0d1219',
  bgGrad: '#121a24',
  stone: '#2a3038',
  stoneDark: '#1a2028',
  stoneLight: '#3a4250',
  stoneMoss: '#2a4a35',
  bridge: '#4a3728',
  bridgeDark: '#3b2c1f',
  bridgeRope: '#6b5540',
  spike: '#6b3a18',
  spikePoint: '#cd853f',
  geraltHair: '#e0ddd4',
  geraltBody: '#1a1a2e',
  geraltArmor: '#2d2d44',
  geraltSword: '#c0c0c0',
  geraltSwordGlow: '#e8e8f0',
  geraltEyes: '#ffd700',
  drowner: '#2e5547',
  drownerlLight: '#3a7061',
  ghoul: '#5c3a3a',
  ghoulLight: '#7a4e4e',
  potion: '#e6a817',
  potionGlow: '#ffd700',
  sign: '#4a90d9',
  signGlow: '#6ab0ff',
  healthBar: '#cc3333',
  healthBg: '#1a1a1a',
  gold: '#daa520',
  text: '#d4c5a9',
  textDim: '#7a7060',
  torchFlame: '#ff8c20',
  torchGlow: '#ff6600',
  fog: '#1a2030',
  chainColor: '#555e6a',
  wallDark: '#151a22',
  wallMid: '#1e252f',
  wallCrack: '#111820',
  vine: '#1e3a28',
  vineLight: '#2a5038',
};

// Seeded random for consistent decorations
function seededRandom(seed: number): number {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

export function render(ctx: CanvasRenderingContext2D, state: GameState, canvasW: number, canvasH: number) {
  ctx.save();

  // Deep background gradient
  const bgGrad = ctx.createLinearGradient(0, 0, 0, canvasH);
  bgGrad.addColorStop(0, COLORS.bg);
  bgGrad.addColorStop(0.4, COLORS.bgMid);
  bgGrad.addColorStop(1, COLORS.bgGrad);
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, canvasW, canvasH);

  // Parallax bg elements
  drawBackground(ctx, state.camera, canvasW, canvasH);

  ctx.translate(-state.camera.x, -state.camera.y);

  // Background wall layer (behind everything)
  drawDungeonWalls(ctx, state.camera, canvasW, canvasH);

  // Background decorations (torches, chains)
  drawDecorations(ctx, state.camera, canvasW);

  // Platforms
  state.platforms.forEach(p => drawPlatform(ctx, p));

  // Ground fog
  drawGroundFog(ctx, state.camera, canvasW);

  // NPCs
  levelNpcs.forEach(npc => drawNpc(ctx, npc, state.npcsSpoken.includes(npc.id)));

  // Pickups
  state.pickups.forEach(p => drawPickup(ctx, p));

  // Enemies
  state.enemies.forEach(e => drawEnemy(ctx, e));

  // Player
  drawPlayer(ctx, state.player);

  // Particles
  state.particles.forEach(p => drawParticle(ctx, p));

  // Foreground atmosphere (vignette fog)
  drawForegroundFog(ctx, state.camera, canvasW, canvasH);

  ctx.restore();

  // HUD
  drawHUD(ctx, state, canvasW);
}

function drawBackground(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, w: number, h: number) {
  // Far distant treeline silhouette
  ctx.fillStyle = '#0a0f15';
  for (let i = 0; i < 12; i++) {
    const x = i * 160 - (camera.x * 0.03) % 160;
    const treeH = 60 + seededRandom(i * 3) * 50;
    ctx.beginPath();
    ctx.moveTo(x, h * 0.75);
    ctx.lineTo(x + 30, h * 0.75 - treeH);
    ctx.lineTo(x + 40, h * 0.75 - treeH * 0.6);
    ctx.lineTo(x + 55, h * 0.75 - treeH * 0.9);
    ctx.lineTo(x + 70, h * 0.75 - treeH * 0.5);
    ctx.lineTo(x + 90, h * 0.75 - treeH * 0.8);
    ctx.lineTo(x + 120, h * 0.75 - treeH * 0.4);
    ctx.lineTo(x + 160, h * 0.75);
    ctx.fill();
  }

  // Mid-ground ruins silhouette
  ctx.fillStyle = '#0e141c';
  for (let i = 0; i < 6; i++) {
    const x = i * 320 - (camera.x * 0.06) % 320;
    const ruinH = 40 + seededRandom(i * 7 + 2) * 60;
    // Tower shapes
    ctx.fillRect(x + 20, h * 0.8 - ruinH, 25, ruinH);
    ctx.fillRect(x + 15, h * 0.8 - ruinH - 8, 35, 8);
    // Broken wall
    ctx.fillRect(x + 60, h * 0.8 - ruinH * 0.5, 80, ruinH * 0.5);
    // Window holes
    ctx.fillStyle = '#060a10';
    ctx.fillRect(x + 28, h * 0.8 - ruinH + 12, 8, 10);
    ctx.fillStyle = '#0e141c';
    // Arch
    ctx.fillRect(x + 150, h * 0.8 - ruinH * 0.3, 15, ruinH * 0.3);
    ctx.fillRect(x + 200, h * 0.8 - ruinH * 0.4, 15, ruinH * 0.4);
    ctx.fillRect(x + 150, h * 0.8 - ruinH * 0.3 - 6, 65, 6);
  }

  // Moon with glow
  const moonX = w * 0.75 - camera.x * 0.015;
  const moonY = 55;
  // Moon glow
  const moonGlow = ctx.createRadialGradient(moonX, moonY, 0, moonX, moonY, 80);
  moonGlow.addColorStop(0, '#c0c0c018');
  moonGlow.addColorStop(0.3, '#c0c0c00a');
  moonGlow.addColorStop(1, 'transparent');
  ctx.fillStyle = moonGlow;
  ctx.fillRect(moonX - 80, moonY - 80, 160, 160);

  // Moon body (crescent)
  ctx.fillStyle = '#c0c0c025';
  ctx.beginPath();
  ctx.arc(moonX, moonY, 22, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = COLORS.bg;
  ctx.beginPath();
  ctx.arc(moonX + 7, moonY - 4, 19, 0, Math.PI * 2);
  ctx.fill();

  // Stars with twinkle
  const time = Date.now() * 0.001;
  for (let i = 0; i < 50; i++) {
    const sx = (i * 137.5 + 50) % w;
    const sy = (i * 73.1 + 10) % (h * 0.5);
    const twinkle = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(time * (1 + seededRandom(i) * 2) + i));
    const size = 0.8 + seededRandom(i * 3) * 1.2;
    ctx.globalAlpha = twinkle * 0.15;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(sx, sy, size, size);
  }
  ctx.globalAlpha = 1;

  // Distant clouds / mist
  ctx.fillStyle = '#1a2030' + '0a';
  for (let i = 0; i < 5; i++) {
    const cx = (i * 280 + time * 3 - camera.x * 0.04) % (w + 200) - 100;
    const cy = 40 + seededRandom(i * 11) * 80;
    const cw = 120 + seededRandom(i * 13) * 100;
    ctx.beginPath();
    ctx.ellipse(cx, cy, cw, 15 + seededRandom(i * 5) * 10, 0, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawDungeonWalls(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, canvasW: number, canvasH: number) {
  const startX = Math.floor(camera.x / 64) * 64;
  const endX = startX + canvasW + 128;

  // Back wall with varied stones
  for (let x = startX; x < endX; x += 64) {
    for (let y = 200; y < canvasH + camera.y; y += 48) {
      const seed = x * 100 + y;
      const shade = 0.7 + seededRandom(seed) * 0.3;
      const r = Math.floor(20 * shade);
      const g = Math.floor(28 * shade);
      const b = Math.floor(38 * shade);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(x, y, 64, 48);

      // Mortar lines
      ctx.fillStyle = COLORS.wallDark;
      ctx.fillRect(x, y, 64, 1);
      ctx.fillRect(x, y, 1, 48);

      // Random cracks
      if (seededRandom(seed + 1) > 0.85) {
        ctx.strokeStyle = COLORS.wallCrack;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x + 10 + seededRandom(seed + 2) * 40, y + 5);
        ctx.lineTo(x + 20 + seededRandom(seed + 3) * 30, y + 25);
        ctx.lineTo(x + 15 + seededRandom(seed + 4) * 35, y + 42);
        ctx.stroke();
      }

      // Moss patches
      if (seededRandom(seed + 5) > 0.9) {
        ctx.fillStyle = COLORS.vine + '60';
        ctx.fillRect(x + 5, y + 2, 12 + seededRandom(seed + 6) * 15, 6);
      }
    }
  }
}

function drawDecorations(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, canvasW: number) {
  const time = Date.now() * 0.001;
  const startX = Math.floor(camera.x / 200) * 200;
  const endX = startX + canvasW + 400;

  for (let x = startX; x < endX; x += 200) {
    const seed = Math.floor(x / 200);
    const type = seededRandom(seed) > 0.5 ? 'torch' : 'chain';

    if (type === 'torch') {
      drawTorch(ctx, x + 50 + seededRandom(seed + 1) * 80, 300 + seededRandom(seed + 2) * 80, time);
    } else {
      drawChain(ctx, x + 30 + seededRandom(seed + 3) * 100, 200, 60 + seededRandom(seed + 4) * 40);
    }

    // Additional hanging vines
    if (seededRandom(seed + 10) > 0.6) {
      drawVines(ctx, x + 100 + seededRandom(seed + 11) * 60, 200);
    }

    // Skull decoration
    if (seededRandom(seed + 20) > 0.8) {
      drawSkull(ctx, x + 140, 390 + seededRandom(seed + 21) * 20);
    }
  }
}

function drawTorch(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  // Bracket
  ctx.fillStyle = '#3a3a3a';
  ctx.fillRect(x - 2, y - 20, 4, 25);
  ctx.fillRect(x - 6, y - 22, 12, 4);

  // Flame glow on wall
  const glowR = 50 + Math.sin(time * 6) * 8;
  const glow = ctx.createRadialGradient(x, y - 25, 0, x, y - 25, glowR);
  glow.addColorStop(0, '#ff880020');
  glow.addColorStop(0.4, '#ff660010');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.fillRect(x - glowR, y - 25 - glowR, glowR * 2, glowR * 2);

  // Flame
  const flicker1 = Math.sin(time * 8 + x) * 2;
  const flicker2 = Math.cos(time * 11 + x) * 1.5;

  // Outer flame
  ctx.fillStyle = '#ff440060';
  ctx.beginPath();
  ctx.moveTo(x - 5, y - 20);
  ctx.quadraticCurveTo(x + flicker1, y - 38 + flicker2, x + 1, y - 20);
  ctx.fill();

  // Inner flame
  ctx.fillStyle = COLORS.torchFlame + '90';
  ctx.beginPath();
  ctx.moveTo(x - 3, y - 20);
  ctx.quadraticCurveTo(x + flicker1 * 0.5, y - 32 + flicker2, x + 1, y - 20);
  ctx.fill();

  // Bright core
  ctx.fillStyle = '#ffcc4490';
  ctx.beginPath();
  ctx.moveTo(x - 1.5, y - 20);
  ctx.quadraticCurveTo(x, y - 26 + flicker2 * 0.5, x + 1, y - 20);
  ctx.fill();

  // Embers
  for (let i = 0; i < 3; i++) {
    const ex = x + Math.sin(time * 3 + i * 2 + x) * 6;
    const ey = y - 30 - ((time * 15 + i * 7 + x) % 20);
    const alpha = 1 - ((time * 15 + i * 7 + x) % 20) / 20;
    ctx.globalAlpha = alpha * 0.6;
    ctx.fillStyle = '#ffaa22';
    ctx.fillRect(ex, ey, 1.5, 1.5);
  }
  ctx.globalAlpha = 1;
}

function drawChain(ctx: CanvasRenderingContext2D, x: number, startY: number, length: number) {
  ctx.strokeStyle = COLORS.chainColor;
  ctx.lineWidth = 2;
  for (let i = 0; i < length; i += 8) {
    ctx.strokeStyle = i % 16 < 8 ? COLORS.chainColor : '#4a5360';
    ctx.beginPath();
    ctx.ellipse(x, startY + i + 4, 2, 4, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
}

function drawVines(ctx: CanvasRenderingContext2D, x: number, startY: number) {
  ctx.strokeStyle = COLORS.vine;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, startY);
  ctx.quadraticCurveTo(x + 8, startY + 30, x - 3, startY + 60);
  ctx.quadraticCurveTo(x + 5, startY + 80, x, startY + 100);
  ctx.stroke();

  // Leaves
  ctx.fillStyle = COLORS.vineLight + '80';
  ctx.beginPath();
  ctx.ellipse(x + 5, startY + 35, 5, 3, 0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(x - 4, startY + 65, 4, 3, -0.3, 0, Math.PI * 2);
  ctx.fill();
}

function drawSkull(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.fillStyle = '#c0b8a820';
  // Cranium
  ctx.beginPath();
  ctx.arc(x, y - 4, 5, Math.PI, 0);
  ctx.fill();
  ctx.fillRect(x - 5, y - 4, 10, 5);
  // Eyes
  ctx.fillStyle = '#0a0a0a60';
  ctx.fillRect(x - 3, y - 4, 2, 2);
  ctx.fillRect(x + 1, y - 4, 2, 2);
  // Jaw
  ctx.fillStyle = '#c0b8a815';
  ctx.fillRect(x - 3, y + 1, 6, 2);
}

function drawGroundFog(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, canvasW: number) {
  const time = Date.now() * 0.001;
  const startX = camera.x - 50;
  const endX = camera.x + canvasW + 50;

  for (let i = 0; i < 12; i++) {
    const fogX = startX + (i * 110 + Math.sin(time * 0.3 + i) * 30);
    if (fogX > endX) continue;
    const fogY = 410 + Math.sin(time * 0.5 + i * 1.3) * 8;
    const fogW = 80 + seededRandom(i * 17) * 60;

    const fogGrad = ctx.createRadialGradient(fogX + fogW / 2, fogY, 0, fogX + fogW / 2, fogY, fogW / 2);
    fogGrad.addColorStop(0, '#2a3a5015');
    fogGrad.addColorStop(0.5, '#1a2a4010');
    fogGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = fogGrad;
    ctx.fillRect(fogX, fogY - fogW / 2, fogW, fogW);
  }
}

function drawForegroundFog(ctx: CanvasRenderingContext2D, camera: { x: number; y: number }, canvasW: number, canvasH: number) {
  // Top darkness vignette
  const topGrad = ctx.createLinearGradient(0, camera.y, 0, camera.y + 80);
  topGrad.addColorStop(0, '#080c1280');
  topGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = topGrad;
  ctx.fillRect(camera.x, camera.y, canvasW, 80);

  // Bottom subtle fog
  const botGrad = ctx.createLinearGradient(0, camera.y + canvasH - 40, 0, camera.y + canvasH);
  botGrad.addColorStop(0, 'transparent');
  botGrad.addColorStop(1, '#0a0e1440');
  ctx.fillStyle = botGrad;
  ctx.fillRect(camera.x, camera.y + canvasH - 40, canvasW, 40);
}

function drawPlatform(ctx: CanvasRenderingContext2D, p: Platform) {
  if (p.type === 'spike') {
    // Blood stains under spikes
    ctx.fillStyle = '#3a1515' + '40';
    ctx.fillRect(p.x - 3, p.y + p.height - 3, p.width + 6, 5);

    for (let i = 0; i < p.width; i += 10) {
      // Spike shadow
      ctx.fillStyle = '#1a0a0a60';
      ctx.beginPath();
      ctx.moveTo(p.x + i - 1, p.y + p.height + 1);
      ctx.lineTo(p.x + i + 5, p.y - 2);
      ctx.lineTo(p.x + i + 11, p.y + p.height + 1);
      ctx.fill();

      // Spike body
      ctx.fillStyle = COLORS.spike;
      ctx.beginPath();
      ctx.moveTo(p.x + i, p.y + p.height);
      ctx.lineTo(p.x + i + 5, p.y);
      ctx.lineTo(p.x + i + 10, p.y + p.height);
      ctx.fill();

      // Spike highlight
      ctx.fillStyle = COLORS.spikePoint;
      ctx.beginPath();
      ctx.moveTo(p.x + i + 4, p.y + 2);
      ctx.lineTo(p.x + i + 5, p.y);
      ctx.lineTo(p.x + i + 6, p.y + 4);
      ctx.fill();
    }
    return;
  }

  if (p.type === 'bridge') {
    // Rope supports
    ctx.strokeStyle = COLORS.bridgeRope;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - 10);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(p.x + p.width, p.y - 10);
    ctx.lineTo(p.x + p.width, p.y);
    ctx.stroke();

    // Planks
    for (let i = 0; i < p.width; i += 14) {
      const plankW = Math.min(12, p.width - i);
      const shade = seededRandom(p.x + i) > 0.5 ? COLORS.bridge : COLORS.bridgeDark;
      ctx.fillStyle = shade;
      ctx.fillRect(p.x + i, p.y, plankW, p.height);
      // Gap between planks
      ctx.fillStyle = '#00000040';
      ctx.fillRect(p.x + i + plankW, p.y, 2, p.height);
      // Wood grain
      ctx.fillStyle = '#00000015';
      ctx.fillRect(p.x + i + 3, p.y + 3, plankW - 4, 1);
      ctx.fillRect(p.x + i + 2, p.y + 8, plankW - 3, 1);
    }

    // Nails
    ctx.fillStyle = '#888';
    ctx.fillRect(p.x + 2, p.y + 2, 2, 2);
    ctx.fillRect(p.x + p.width - 4, p.y + 2, 2, 2);
    return;
  }

  // ===== Stone platform =====
  // Shadow below
  ctx.fillStyle = '#00000025';
  ctx.fillRect(p.x + 3, p.y + p.height, p.width, 4);

  // Main body
  ctx.fillStyle = COLORS.stone;
  ctx.fillRect(p.x, p.y, p.width, p.height);

  // Brick pattern with varied shading
  for (let row = 0; row < p.height; row += 16) {
    const offset = (row / 16) % 2 === 0 ? 0 : 20;
    for (let col = 0; col < p.width; col += 40) {
      const brickX = p.x + col + offset;
      const brickW = Math.min(38, p.x + p.width - brickX);
      if (brickW <= 0) continue;

      const seed = brickX * 7 + (p.y + row) * 13;
      const shade = 0.85 + seededRandom(seed) * 0.3;
      const r = Math.floor(42 * shade);
      const g = Math.floor(48 * shade);
      const b = Math.floor(56 * shade);
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(brickX, p.y + row, brickW, 15);

      // Mortar
      ctx.fillStyle = COLORS.stoneDark;
      ctx.fillRect(brickX, p.y + row, brickW, 1);
      ctx.fillRect(brickX, p.y + row, 1, 15);

      // Random damage
      if (seededRandom(seed + 1) > 0.88) {
        ctx.fillStyle = COLORS.stoneDark;
        ctx.fillRect(brickX + 5, p.y + row + 4, 6, 3);
      }

      // Moss on some bricks
      if (seededRandom(seed + 2) > 0.92) {
        ctx.fillStyle = COLORS.stoneMoss + '50';
        ctx.fillRect(brickX + 2, p.y + row + 10, 10, 4);
      }
    }
  }

  // Top edge with grout highlight
  ctx.fillStyle = COLORS.stoneLight;
  ctx.fillRect(p.x, p.y, p.width, 2);

  // Top edge moss patches
  for (let i = 0; i < p.width; i += 30) {
    if (seededRandom(p.x + i + p.y) > 0.6) {
      ctx.fillStyle = COLORS.stoneMoss + '40';
      const mossW = 8 + seededRandom(p.x + i) * 12;
      ctx.fillRect(p.x + i, p.y - 1, mossW, 3);
    }
  }

  // Bottom edge shadow
  if (p.height > 20) {
    ctx.fillStyle = COLORS.stoneDark;
    ctx.fillRect(p.x, p.y + p.height - 2, p.width, 2);
  }
}

function drawPlayer(ctx: CanvasRenderingContext2D, p: Player) {
  if (p.state === 'dead') return;

  const cx = p.pos.x + p.width / 2;
  const flash = p.invulnerable > 0 && Math.floor(p.invulnerable / 4) % 2 === 0;
  if (flash) ctx.globalAlpha = 0.5;

  ctx.save();
  ctx.translate(cx, p.pos.y + p.height);
  ctx.scale(p.facing, 1);

  const legAnim = p.state === 'run' ? Math.sin(p.animTimer * 0.3) * 6 : 0;
  const breathe = Math.sin(p.animTimer * 0.05) * 0.5;

  // Shadow
  ctx.fillStyle = '#00000030';
  ctx.beginPath();
  ctx.ellipse(0, 0, 10, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  // Boots
  ctx.fillStyle = '#1a1a22';
  drawRoundRect(ctx, -7, -4, 6, 4, 1);
  drawRoundRect(ctx, 1, -4 + Math.abs(legAnim) * 0.2, 6, 4, 1);

  // Legs - dark trousers
  ctx.fillStyle = '#1e1e2a';
  drawRoundRect(ctx, -6, -16, 5, 13, 1);
  drawRoundRect(ctx, 1, -16 + legAnim * 0.5, 5, 13 - Math.abs(legAnim) * 0.3, 1);

  // Body - dark leather armor
  ctx.fillStyle = '#252538';
  drawRoundRect(ctx, -9, -32 + breathe, 18, 18, 2);

  // Armor detail - chest piece with stitching
  ctx.fillStyle = '#303048';
  drawRoundRect(ctx, -7, -30 + breathe, 14, 10, 1);

  // Shoulder pauldrons
  ctx.fillStyle = '#2a2a40';
  drawRoundRect(ctx, -10, -32 + breathe, 5, 6, 2);
  drawRoundRect(ctx, 5, -32 + breathe, 5, 6, 2);

  // Armor studs (rivets)
  ctx.fillStyle = '#606080';
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(-4 + i * 4, -26 + breathe, 1, 0, Math.PI * 2);
    ctx.fill();
  }

  // Belt
  ctx.fillStyle = '#3a2a1a';
  drawRoundRect(ctx, -9, -15, 18, 3, 1);
  // Belt buckle (wolf head)
  ctx.fillStyle = COLORS.gold;
  drawRoundRect(ctx, -2, -15, 4, 3, 1);

  // Neck
  ctx.fillStyle = '#d0c4b0';
  drawRoundRect(ctx, -3, -35 + breathe, 6, 4, 1);

  // Head
  ctx.fillStyle = '#dbd0c0';
  drawRoundRect(ctx, -6, -42, 12, 10, 3);

  // White hair - flowing
  ctx.fillStyle = COLORS.geraltHair;
  drawRoundRect(ctx, -7, -44, 14, 6, 3);
  // Side hair
  drawRoundRect(ctx, 5, -42, 3, 10, 1);
  // Ponytail
  ctx.fillStyle = '#d0ccc0';
  drawRoundRect(ctx, 6, -40, 2, 8, 1);
  drawRoundRect(ctx, 7, -34, 2, 5, 1);

  // Face details
  // Eyes (cat-like amber)
  ctx.fillStyle = '#111';
  drawRoundRect(ctx, -3, -38, 3, 2, 1);
  drawRoundRect(ctx, 1, -38, 3, 2, 1);
  ctx.fillStyle = COLORS.geraltEyes;
  ctx.fillRect(-2, -38, 1.5, 1.5);
  ctx.fillRect(2, -38, 1.5, 1.5);

  // Scar (left eye)
  ctx.strokeStyle = '#aa6666';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, -41);
  ctx.lineTo(-1, -37);
  ctx.lineTo(0, -33);
  ctx.stroke();

  // Stubble
  ctx.fillStyle = '#c0b8a840';
  drawRoundRect(ctx, -4, -34, 8, 2, 1);

  // Active sword rendering
  const ironColor = '#6a6058';
  const ironGlow = '#8a7868';
  const silverColor = '#c0c8d8';
  const silverGlow = '#e0e8f8';
  const swordColor = p.activeSword === 'silver' ? silverColor : ironColor;
  const swordGlowColor = p.activeSword === 'silver' ? silverGlow : ironGlow;

  if (p.state === 'attack') {
    const angle = -Math.PI / 4 + (p.attackTimer / 15) * Math.PI * 0.8;
    ctx.save();
    ctx.translate(5, -28);
    ctx.rotate(angle);
    // Blade
    ctx.fillStyle = swordColor;
    drawRoundRect(ctx, -1.5, -30, 3, 30, 1);
    // Blade edge highlight
    ctx.fillStyle = swordGlowColor;
    ctx.fillRect(-1.5, -30, 1, 8);
    // Guard (crossguard)
    ctx.fillStyle = p.activeSword === 'silver' ? '#888' : COLORS.gold;
    drawRoundRect(ctx, -4, -2, 8, 3, 1);
    // Grip (leather wrapped)
    ctx.fillStyle = p.activeSword === 'silver' ? '#2a2a3a' : '#3a2a1a';
    drawRoundRect(ctx, -1.5, 1, 3, 7, 1);
    // Pommel
    ctx.fillStyle = p.activeSword === 'silver' ? '#999' : COLORS.gold;
    ctx.beginPath();
    ctx.arc(0, 9, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else {
    // Both swords on back
    ctx.save();
    ctx.translate(-4, -42);
    ctx.rotate(-0.2);
    // Silver
    ctx.fillStyle = silverColor;
    drawRoundRect(ctx, -1, -22, 2, 22, 1);
    ctx.fillStyle = '#888';
    drawRoundRect(ctx, -2.5, -1, 5, 2, 1);
    ctx.restore();
    ctx.save();
    ctx.translate(-6, -40);
    ctx.rotate(-0.3);
    // Iron
    ctx.fillStyle = ironColor;
    drawRoundRect(ctx, -1, -20, 2, 20, 1);
    ctx.fillStyle = COLORS.gold;
    drawRoundRect(ctx, -2.5, -1, 5, 2, 1);
    ctx.restore();
  }

  // Witcher medallion
  const time = Date.now() * 0.003;
  const medalGlow = 0.5 + Math.sin(time) * 0.2;
  ctx.globalAlpha = flash ? 0.5 : medalGlow;
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(0, -30 + breathe, 3, 0, Math.PI * 2);
  ctx.fill();
  // Chain
  ctx.strokeStyle = '#aa8800';
  ctx.lineWidth = 0.5;
  ctx.beginPath();
  ctx.moveTo(-2, -33 + breathe);
  ctx.lineTo(0, -30 + breathe);
  ctx.lineTo(2, -33 + breathe);
  ctx.stroke();
  ctx.globalAlpha = flash ? 0.5 : 1;

  ctx.restore();
  ctx.globalAlpha = 1;
}

// Utility for rounded rectangles
function drawRoundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();
}

function drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy) {
  if (e.state === 'dead' && e.deathTimer <= 0) return;

  const cx = e.pos.x + e.width / 2;
  const alpha = e.state === 'dead' ? e.deathTimer / 30 : 1;
  ctx.globalAlpha = alpha;

  ctx.save();
  ctx.translate(cx, e.pos.y + e.height);
  ctx.scale(e.facing, 1);

  const bobAnim = Math.sin(e.animTimer * 0.1) * 1.5;

  // Shadow
  ctx.fillStyle = '#00000025';
  ctx.beginPath();
  ctx.ellipse(0, 0, 9, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  if (e.type === 'drowner') {
    const isHurt = e.state === 'hurt';
    const bodyColor = isHurt ? '#5aaa80' : COLORS.drowner;
    const darkColor = isHurt ? '#488a68' : '#1e4535';

    // Dripping water
    ctx.fillStyle = bodyColor + '30';
    for (let i = 0; i < 3; i++) {
      const dripY = (e.animTimer * 0.5 + i * 11) % 12;
      ctx.beginPath();
      ctx.ellipse(-4 + i * 4, -dripY, 1, 1.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Legs (webbed)
    ctx.fillStyle = darkColor;
    drawRoundRect(ctx, -5, -12, 4, 12, 1);
    drawRoundRect(ctx, 1, -12, 4, 12, 1);
    // Webbed feet
    ctx.fillStyle = darkColor;
    drawRoundRect(ctx, -7, -2, 7, 2, 1);
    drawRoundRect(ctx, 0, -2, 7, 2, 1);

    // Body (hunched, slimy)
    ctx.fillStyle = bodyColor;
    drawRoundRect(ctx, -8, -30 + bobAnim, 16, 20, 3);
    // Rib texture
    ctx.fillStyle = COLORS.drownerlLight + '50';
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(-5, -27 + bobAnim + i * 5, 10, 1);
    }

    // Head (fish-like)
    ctx.fillStyle = bodyColor;
    drawRoundRect(ctx, -6, -38 + bobAnim, 12, 10, 4);

    // Large bulging eye
    ctx.fillStyle = '#ccffcc';
    ctx.beginPath();
    ctx.arc(2, -34 + bobAnim, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#115511';
    ctx.beginPath();
    ctx.arc(2.5, -34 + bobAnim, 1.5, 0, Math.PI * 2);
    ctx.fill();

    // Mouth (wide, gaping)
    ctx.fillStyle = '#0a2a1a';
    drawRoundRect(ctx, -4, -30 + bobAnim, 8, 3, 1);
    // Tiny teeth
    ctx.fillStyle = '#aaeeaa60';
    for (let i = 0; i < 4; i++) {
      ctx.fillRect(-3 + i * 2, -30 + bobAnim, 1, 1.5);
    }

    // Claws (long, curved)
    ctx.fillStyle = darkColor;
    ctx.strokeStyle = darkColor;
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(7, -26 + bobAnim + i * 3);
      ctx.quadraticCurveTo(12, -27 + bobAnim + i * 3, 11, -24 + bobAnim + i * 3);
      ctx.stroke();
    }

  } else if (e.type === 'ghoul') {
    const isHurt = e.state === 'hurt';
    const bodyColor = isHurt ? '#aa6666' : COLORS.ghoul;
    const darkColor = isHurt ? '#884444' : '#3a1a1a';

    // Blood drips
    ctx.fillStyle = '#5c3a3a40';
    ctx.beginPath();
    ctx.ellipse(3, -2, 2, 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // Legs (muscular)
    ctx.fillStyle = darkColor;
    drawRoundRect(ctx, -7, -12, 6, 12, 2);
    drawRoundRect(ctx, 1, -12, 6, 12, 2);
    // Talons
    ctx.fillStyle = '#2a0a0a';
    drawRoundRect(ctx, -8, -2, 7, 2, 1);
    drawRoundRect(ctx, 1, -2, 7, 2, 1);

    // Body (hunched, massive)
    ctx.fillStyle = bodyColor;
    drawRoundRect(ctx, -10, -34 + bobAnim, 20, 24, 3);
    // Muscle ridges
    ctx.fillStyle = COLORS.ghoulLight + '30';
    drawRoundRect(ctx, -7, -30 + bobAnim, 14, 3, 1);
    drawRoundRect(ctx, -6, -22 + bobAnim, 12, 3, 1);

    // Head (bestial)
    ctx.fillStyle = bodyColor;
    drawRoundRect(ctx, -8, -44 + bobAnim, 16, 12, 4);

    // Horns
    ctx.fillStyle = '#4a2a2a';
    ctx.beginPath();
    ctx.moveTo(-7, -42 + bobAnim);
    ctx.lineTo(-10, -50 + bobAnim);
    ctx.lineTo(-5, -44 + bobAnim);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(7, -42 + bobAnim);
    ctx.lineTo(10, -50 + bobAnim);
    ctx.lineTo(5, -44 + bobAnim);
    ctx.fill();

    // Glowing eyes
    ctx.fillStyle = '#ff3333';
    ctx.beginPath();
    ctx.arc(1, -39 + bobAnim, 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff8888';
    ctx.beginPath();
    ctx.arc(1.5, -39.5 + bobAnim, 1, 0, Math.PI * 2);
    ctx.fill();
    // Eye glow effect
    ctx.fillStyle = '#ff000018';
    ctx.beginPath();
    ctx.arc(1, -39 + bobAnim, 8, 0, Math.PI * 2);
    ctx.fill();

    // Jaw with prominent teeth
    ctx.fillStyle = '#2a1010';
    drawRoundRect(ctx, -6, -34 + bobAnim, 12, 4, 2);
    ctx.fillStyle = '#dddddd90';
    for (let i = 0; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(-4 + i * 2.5, -32 + bobAnim);
      ctx.lineTo(-3 + i * 2.5, -29 + bobAnim);
      ctx.lineTo(-2 + i * 2.5, -32 + bobAnim);
      ctx.fill();
    }

    // Large claws
    ctx.strokeStyle = '#4a2020';
    ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(9, -30 + bobAnim + i * 4);
      ctx.quadraticCurveTo(16, -32 + bobAnim + i * 4, 14, -27 + bobAnim + i * 4);
      ctx.stroke();
    }

  } else if (e.type === 'bandit') {
    const isHurt = e.state === 'hurt';
    const bodyColor = isHurt ? '#bbaa88' : '#6a5a42';
    const skinColor = isHurt ? '#ddc8a8' : '#c8b8a0';

    // Legs
    ctx.fillStyle = isHurt ? '#aa9978' : '#5a4a38';
    drawRoundRect(ctx, -5, -14, 4, 14, 1);
    drawRoundRect(ctx, 1, -14, 4, 14, 1);
    // Boots
    ctx.fillStyle = '#3a2a1a';
    drawRoundRect(ctx, -6, -2, 5, 3, 1);
    drawRoundRect(ctx, 1, -2, 5, 3, 1);

    // Body - leather jerkin
    ctx.fillStyle = bodyColor;
    drawRoundRect(ctx, -8, -30 + bobAnim, 16, 18, 2);
    // Leather stitching detail
    ctx.strokeStyle = '#5a4a3060';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(0, -28 + bobAnim);
    ctx.lineTo(0, -14 + bobAnim);
    ctx.stroke();

    // Belt
    ctx.fillStyle = '#4a3a28';
    drawRoundRect(ctx, -8, -14, 16, 3, 1);
    ctx.fillStyle = '#aa9060';
    drawRoundRect(ctx, -1, -14, 2, 3, 1);

    // Head
    ctx.fillStyle = skinColor;
    drawRoundRect(ctx, -5, -38 + bobAnim, 10, 10, 3);

    // Bandana
    ctx.fillStyle = '#6a3030';
    drawRoundRect(ctx, -6, -40 + bobAnim, 12, 5, 2);
    // Bandana knot
    ctx.fillStyle = '#5a2020';
    drawRoundRect(ctx, -7, -37 + bobAnim, 3, 4, 1);

    // Eyes (menacing)
    ctx.fillStyle = '#221100';
    drawRoundRect(ctx, -3, -35 + bobAnim, 2, 2, 1);
    drawRoundRect(ctx, 2, -35 + bobAnim, 2, 2, 1);

    // Stubble/beard
    ctx.fillStyle = '#9a886860';
    drawRoundRect(ctx, -3, -30 + bobAnim, 6, 3, 1);

    // Sword in hand
    ctx.fillStyle = '#8a8078';
    drawRoundRect(ctx, 7, -28 + bobAnim, 2, 18, 1);
    ctx.fillStyle = '#aa9060';
    drawRoundRect(ctx, 6, -12 + bobAnim, 4, 2, 1);

  } else if (e.type === 'deserter') {
    const isHurt = e.state === 'hurt';
    const armorColor = isHurt ? '#8899aa' : '#5a6070';
    const skinColor = isHurt ? '#ddc8a8' : '#c0b098';

    // Legs (armored)
    ctx.fillStyle = isHurt ? '#7788aa' : '#4a5060';
    drawRoundRect(ctx, -6, -14, 5, 14, 1);
    drawRoundRect(ctx, 1, -14, 5, 14, 1);
    // Greaves
    ctx.fillStyle = '#3a4050';
    drawRoundRect(ctx, -7, -8, 6, 4, 1);
    drawRoundRect(ctx, 1, -8, 6, 4, 1);
    // Boots
    ctx.fillStyle = '#3a3a3a';
    drawRoundRect(ctx, -7, -2, 6, 3, 1);
    drawRoundRect(ctx, 1, -2, 6, 3, 1);

    // Body - chainmail
    ctx.fillStyle = armorColor;
    drawRoundRect(ctx, -9, -32 + bobAnim, 18, 20, 2);
    // Chainmail pattern
    ctx.fillStyle = '#4a506050';
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 5; col++) {
        ctx.beginPath();
        ctx.arc(-6 + col * 3, -29 + bobAnim + row * 5, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    // Torn tabard
    ctx.fillStyle = '#3a4a6040';
    drawRoundRect(ctx, -4, -30 + bobAnim, 8, 16, 1);

    // Head
    ctx.fillStyle = skinColor;
    drawRoundRect(ctx, -5, -40 + bobAnim, 10, 10, 3);

    // Open-face helmet
    ctx.fillStyle = '#6a6a6a';
    drawRoundRect(ctx, -6, -43 + bobAnim, 12, 6, 2);
    // Cheek guards
    drawRoundRect(ctx, -7, -40 + bobAnim, 3, 8, 1);
    drawRoundRect(ctx, 4, -40 + bobAnim, 3, 8, 1);
    // Nose guard
    ctx.fillStyle = '#555';
    drawRoundRect(ctx, -1, -40 + bobAnim, 2, 5, 1);

    // Eyes
    ctx.fillStyle = '#332211';
    drawRoundRect(ctx, -3, -37 + bobAnim, 2, 2, 1);
    drawRoundRect(ctx, 2, -37 + bobAnim, 2, 2, 1);

    // Sword
    ctx.fillStyle = '#8a8a8a';
    drawRoundRect(ctx, 8, -30 + bobAnim, 2, 20, 1);
    ctx.fillStyle = '#aa9060';
    drawRoundRect(ctx, 7, -12 + bobAnim, 4, 2, 1);

    // Shield on back
    ctx.fillStyle = '#5a4a38';
    drawRoundRect(ctx, -11, -32 + bobAnim, 4, 14, 2);
    ctx.fillStyle = '#3a4a6a';
    drawRoundRect(ctx, -10, -29 + bobAnim, 2, 8, 1);
  }

  // Health bar for enemies
  if (e.state !== 'dead' && e.health < e.maxHealth) {
    const barW = 24;
    const barH = 3;
    ctx.fillStyle = '#00000080';
    drawRoundRect(ctx, -barW / 2, -48 + bobAnim, barW, barH, 1);
    ctx.fillStyle = e.race === 'human' ? '#cc6633' : '#33cc66';
    const healthW = (e.health / e.maxHealth) * barW;
    drawRoundRect(ctx, -barW / 2, -48 + bobAnim, healthW, barH, 1);
  }

  ctx.restore();
  ctx.globalAlpha = 1;
}

function drawPickup(ctx: CanvasRenderingContext2D, p: { x: number; y: number; type: string; collected: boolean }) {
  if (p.collected) return;

  const time = Date.now() * 0.001;
  const bob = Math.sin(time * 3 + p.x * 0.1) * 4;

  if (p.type === 'potion') {
    // Glow
    const glowR = 14 + Math.sin(time * 4) * 2;
    const glow = ctx.createRadialGradient(p.x, p.y + bob, 0, p.x, p.y + bob, glowR);
    glow.addColorStop(0, '#ffd70020');
    glow.addColorStop(0.6, '#ff880010');
    glow.addColorStop(1, 'transparent');
    ctx.fillStyle = glow;
    ctx.fillRect(p.x - glowR, p.y + bob - glowR, glowR * 2, glowR * 2);

    // Bottle body
    ctx.fillStyle = '#8b6914';
    ctx.fillRect(p.x - 5, p.y - 5 + bob, 10, 12);
    // Liquid
    ctx.fillStyle = COLORS.potion;
    ctx.fillRect(p.x - 4, p.y - 2 + bob, 8, 8);
    // Neck
    ctx.fillStyle = '#8b6914';
    ctx.fillRect(p.x - 2, p.y - 8 + bob, 4, 4);
    // Cork
    ctx.fillStyle = '#6b5540';
    ctx.fillRect(p.x - 2, p.y - 9 + bob, 4, 2);
    // Liquid shimmer
    ctx.fillStyle = '#ffffff30';
    ctx.fillRect(p.x - 3, p.y + bob, 2, 5);
    // Label
    ctx.fillStyle = '#ffffff15';
    ctx.fillRect(p.x - 3, p.y + 2 + bob, 6, 3);
  } else {
    // Aard sign - magical glow
    const glowR = 18 + Math.sin(time * 3) * 3;
    const glow = ctx.createRadialGradient(p.x, p.y + bob, 0, p.x, p.y + bob, glowR);
    glow.addColorStop(0, '#6ab0ff18');
    glow.addColorStop(0.5, '#4a90d910');
    glow.addColorStop(1, 'transparent');
    ctx.fillStyle = glow;
    ctx.fillRect(p.x - glowR, p.y + bob - glowR, glowR * 2, glowR * 2);

    // Rotating rune circle
    ctx.save();
    ctx.translate(p.x, p.y + bob);
    ctx.rotate(time * 0.5);
    ctx.strokeStyle = COLORS.sign + '60';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, 10, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // Triangle sign
    ctx.strokeStyle = COLORS.sign;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - 8 + bob);
    ctx.lineTo(p.x + 7, p.y + 5 + bob);
    ctx.lineTo(p.x - 7, p.y + 5 + bob);
    ctx.closePath();
    ctx.stroke();

    // Center dot
    ctx.fillStyle = COLORS.signGlow;
    ctx.beginPath();
    ctx.arc(p.x, p.y + bob, 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Inner glow
    ctx.fillStyle = '#ffffff30';
    ctx.beginPath();
    ctx.arc(p.x, p.y + bob, 1, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawParticle(ctx: CanvasRenderingContext2D, p: Particle) {
  ctx.globalAlpha = p.life / p.maxLife;
  ctx.fillStyle = p.color;
  ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
  ctx.globalAlpha = 1;
}

function drawHUD(ctx: CanvasRenderingContext2D, state: GameState, canvasW: number) {
  // HUD background
  ctx.fillStyle = '#0a0e1480';
  ctx.fillRect(8, 8, 145, 38);

  // Health bar
  const barW = 120;
  const barH = 12;
  const barX = 16;
  const barY = 16;

  ctx.fillStyle = COLORS.healthBg;
  ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);

  const healthPct = state.player.health / state.player.maxHealth;
  if (healthPct > 0) {
    const healthGrad = ctx.createLinearGradient(barX, barY, barX + barW * healthPct, barY);
    healthGrad.addColorStop(0, healthPct > 0.3 ? '#882222' : '#aa1111');
    healthGrad.addColorStop(1, healthPct > 0.3 ? COLORS.healthBar : '#ff2222');
    ctx.fillStyle = healthGrad;
    ctx.fillRect(barX, barY, barW * healthPct, barH);

    // Health bar shine
    ctx.fillStyle = '#ffffff10';
    ctx.fillRect(barX, barY, barW * healthPct, barH / 2);
  }

  // Health label
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '9px monospace';
  ctx.fillText('VITALITY', barX, barY + barH + 12);

  // Score with icon
  ctx.fillStyle = COLORS.gold;
  ctx.font = 'bold 13px monospace';
  ctx.textAlign = 'right';
  ctx.fillText(`⬡ ${state.score}`, canvasW - 16, 24);
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '9px monospace';
  ctx.fillText('ORENS', canvasW - 16, 36);
  ctx.textAlign = 'left';

  // Controls hint (desktop only)
  ctx.fillStyle = COLORS.textDim + '80';
  ctx.font = '8px monospace';
  ctx.fillText('← → MOVE  ↑ JUMP  SPACE Iron  Q Silver', 12, 472);
}

export function drawTitleScreen(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const time = Date.now() * 0.001;

  // Background
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#060a10');
  grad.addColorStop(0.4, '#0c1018');
  grad.addColorStop(0.7, '#101820');
  grad.addColorStop(1, '#060a10');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Atmospheric particles
  for (let i = 0; i < 60; i++) {
    const px = (i * 73.7 + time * 8) % w;
    const py = (i * 137.3 + Math.sin(time * 0.5 + i) * 25) % h;
    const alpha = 0.02 + seededRandom(i) * 0.06;
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(px, py, 1 + seededRandom(i * 3), 1 + seededRandom(i * 3));
  }
  ctx.globalAlpha = 1;

  // Medallion glow
  const glowSize = 70 + Math.sin(time * 1.5) * 8;
  const glow = ctx.createRadialGradient(w / 2, h * 0.33, 0, w / 2, h * 0.33, glowSize);
  glow.addColorStop(0, '#daa52020');
  glow.addColorStop(0.3, '#daa52010');
  glow.addColorStop(0.7, '#ff660005');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);

  // Outer ring
  ctx.strokeStyle = COLORS.gold + '40';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(w / 2, h * 0.33, 32, 0, Math.PI * 2);
  ctx.stroke();

  // Medallion circle
  ctx.strokeStyle = COLORS.gold;
  ctx.lineWidth = 2;
  const mx = w / 2;
  const my = h * 0.33;
  ctx.beginPath();
  ctx.arc(mx, my, 25, 0, Math.PI * 2);
  ctx.stroke();

  // Wolf head
  ctx.fillStyle = COLORS.gold;
  ctx.beginPath();
  ctx.moveTo(mx - 10, my + 8);
  ctx.lineTo(mx - 14, my - 8);
  ctx.lineTo(mx - 8, my - 4);
  ctx.lineTo(mx, my - 14);
  ctx.lineTo(mx + 8, my - 4);
  ctx.lineTo(mx + 14, my - 8);
  ctx.lineTo(mx + 10, my + 8);
  ctx.lineTo(mx, my + 12);
  ctx.closePath();
  ctx.fill();

  // Wolf eyes
  ctx.fillStyle = '#ffffff80';
  ctx.fillRect(mx - 5, my - 2, 2, 2);
  ctx.fillRect(mx + 3, my - 2, 2, 2);

  // Title
  ctx.fillStyle = COLORS.text;
  ctx.font = 'bold 28px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('THE WITCHER', w / 2, h * 0.52);

  // Subtitle with decorative line
  ctx.fillStyle = COLORS.textDim;
  ctx.font = '11px monospace';
  ctx.fillText('─── DUNGEON OF THE WHITE WOLF ───', w / 2, h * 0.52 + 22);

  // Version / flavor text
  ctx.fillStyle = COLORS.textDim + '60';
  ctx.font = '8px monospace';
  ctx.fillText('BASED ON THE WORKS OF ANDRZEJ SAPKOWSKI', w / 2, h * 0.52 + 42);

  // Start prompt
  const blink = Math.sin(time * 4) > 0;
  if (blink) {
    ctx.fillStyle = COLORS.gold;
    ctx.font = '13px monospace';
    ctx.fillText('PRESS ANY KEY TO START', w / 2, h * 0.75);
  }

  // Decorative bottom border
  ctx.strokeStyle = COLORS.textDim + '30';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(w * 0.2, h * 0.85);
  ctx.lineTo(w * 0.8, h * 0.85);
  ctx.stroke();

  ctx.textAlign = 'left';
}

export function drawGameOver(ctx: CanvasRenderingContext2D, w: number, h: number, score: number) {
  ctx.fillStyle = '#000000aa';
  ctx.fillRect(0, 0, w, h);

  // Blood vignette
  const vignette = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.6);
  vignette.addColorStop(0, 'transparent');
  vignette.addColorStop(1, '#33000040');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = COLORS.healthBar;
  ctx.font = 'bold 26px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('YOU DIED', w / 2, h * 0.38);

  ctx.fillStyle = COLORS.textDim;
  ctx.font = '11px monospace';
  ctx.fillText('The White Wolf falls...', w / 2, h * 0.46);

  ctx.fillStyle = COLORS.gold;
  ctx.font = '12px monospace';
  ctx.fillText(`ORENS COLLECTED: ${score}`, w / 2, h * 0.55);

  const blink = Math.sin(Date.now() * 0.004) > 0;
  if (blink) {
    ctx.fillStyle = COLORS.text;
    ctx.font = '13px monospace';
    ctx.fillText('PRESS ANY KEY TO RETRY', w / 2, h * 0.68);
  }
  ctx.textAlign = 'left';
}

export function drawGameWon(ctx: CanvasRenderingContext2D, w: number, h: number, score: number) {
  ctx.fillStyle = '#000000aa';
  ctx.fillRect(0, 0, w, h);

  // Gold vignette
  const vignette = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.5);
  vignette.addColorStop(0, '#daa52010');
  vignette.addColorStop(1, 'transparent');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = COLORS.gold;
  ctx.font = 'bold 24px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('QUEST COMPLETE', w / 2, h * 0.38);

  ctx.fillStyle = COLORS.text;
  ctx.font = '11px monospace';
  ctx.fillText('The dungeon is cleared.', w / 2, h * 0.46);

  ctx.fillStyle = COLORS.gold;
  ctx.font = '12px monospace';
  ctx.fillText(`ORENS: ${score}`, w / 2, h * 0.55);

  const blink = Math.sin(Date.now() * 0.004) > 0;
  if (blink) {
    ctx.fillStyle = COLORS.gold;
    ctx.font = '13px monospace';
    ctx.fillText('PRESS ANY KEY TO PLAY AGAIN', w / 2, h * 0.68);
  }
  ctx.textAlign = 'left';
}


// ====== STORY RENDERING ======

export function drawIntroCrawl(ctx: CanvasRenderingContext2D, w: number, h: number, lineIndex: number, charIndex: number) {
  // Dark background
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#040608');
  grad.addColorStop(0.5, '#0a1018');
  grad.addColorStop(1, '#040608');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Subtle particles
  const time = Date.now() * 0.001;
  ctx.fillStyle = '#ffffff06';
  for (let i = 0; i < 30; i++) {
    const px = (i * 73.7 + time * 5) % w;
    const py = (i * 137.3 + Math.sin(time * 0.3 + i) * 15) % h;
    ctx.fillRect(px, py, 1, 1);
  }

  // Decorative top/bottom borders
  ctx.strokeStyle = '#daa52020';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(w * 0.1, 30);
  ctx.lineTo(w * 0.9, 30);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(w * 0.1, h - 30);
  ctx.lineTo(w * 0.9, h - 30);
  ctx.stroke();

  // Render lines with typewriter effect
  ctx.textAlign = 'center';
  const startY = 60;
  const lineHeight = 20;

  for (let i = 0; i <= lineIndex && i < introCrawl.length; i++) {
    const line = introCrawl[i];
    let displayText = line;

    if (i === lineIndex) {
      displayText = line.substring(0, charIndex);
    }

    // Color based on content
    if (line.startsWith('"')) {
      ctx.fillStyle = '#d4c5a9';
      ctx.font = 'italic 12px monospace';
    } else if (line === '') {
      continue;
    } else {
      ctx.fillStyle = '#8a8070';
      ctx.font = '12px monospace';
    }

    ctx.fillText(displayText, w / 2, startY + i * lineHeight);
  }

  // Continue prompt
  if (lineIndex >= introCrawl.length - 1 && charIndex >= introCrawl[introCrawl.length - 1].length) {
    const blink = Math.sin(Date.now() * 0.004) > 0;
    if (blink) {
      ctx.fillStyle = COLORS.gold;
      ctx.font = '11px monospace';
      ctx.fillText('PRESS ANY KEY TO CONTINUE', w / 2, h - 50);
    }
  } else {
    ctx.fillStyle = '#555';
    ctx.font = '9px monospace';
    ctx.fillText('TAP / PRESS KEY TO SKIP', w / 2, h - 50);
  }

  ctx.textAlign = 'left';
}

export function drawDialogue(ctx: CanvasRenderingContext2D, w: number, h: number, npcId: string, lineIndex: number) {
  const npc = levelNpcs.find(n => n.id === npcId);
  if (!npc) return;
  const line = npc.dialogue[lineIndex];
  if (!line) return;

  // Dialogue box background
  const boxH = 100;
  const boxY = h - boxH - 10;
  const boxX = 10;
  const boxW = w - 20;

  // Semi-transparent dark background
  ctx.fillStyle = '#0a0e14e8';
  ctx.fillRect(boxX, boxY, boxW, boxH);

  // Border
  ctx.strokeStyle = line.speaker === 'Geralt' ? '#daa52060' : '#4a90d960';
  ctx.lineWidth = 2;
  ctx.strokeRect(boxX, boxY, boxW, boxH);

  // Corner ornaments
  const cornerSize = 8;
  ctx.fillStyle = line.speaker === 'Geralt' ? COLORS.gold : '#4a90d9';
  // Top-left
  ctx.fillRect(boxX, boxY, cornerSize, 2);
  ctx.fillRect(boxX, boxY, 2, cornerSize);
  // Top-right
  ctx.fillRect(boxX + boxW - cornerSize, boxY, cornerSize, 2);
  ctx.fillRect(boxX + boxW - 2, boxY, 2, cornerSize);
  // Bottom-left
  ctx.fillRect(boxX, boxY + boxH - 2, cornerSize, 2);
  ctx.fillRect(boxX, boxY + boxH - cornerSize, 2, cornerSize);
  // Bottom-right
  ctx.fillRect(boxX + boxW - cornerSize, boxY + boxH - 2, cornerSize, 2);
  ctx.fillRect(boxX + boxW - 2, boxY + boxH - cornerSize, 2, cornerSize);

  // Speaker name
  ctx.fillStyle = line.speaker === 'Geralt' ? COLORS.gold : '#6ab0ff';
  ctx.font = 'bold 11px monospace';
  ctx.fillText(line.speaker, boxX + 14, boxY + 20);

  // Dialogue text (word wrap)
  ctx.fillStyle = '#d4c5a9';
  ctx.font = '11px monospace';
  const maxLineW = boxW - 28;
  const words = line.text.split(' ');
  let currentLine = '';
  let textY = boxY + 40;

  for (const word of words) {
    const testLine = currentLine ? currentLine + ' ' + word : word;
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxLineW && currentLine) {
      ctx.fillText(currentLine, boxX + 14, textY);
      currentLine = word;
      textY += 16;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) {
    ctx.fillText(currentLine, boxX + 14, textY);
  }

  // Continue prompt
  const blink = Math.sin(Date.now() * 0.005) > 0;
  if (blink) {
    ctx.fillStyle = '#8a807080';
    ctx.font = '9px monospace';
    ctx.textAlign = 'right';
    ctx.fillText('▶ TAP / KEY', boxX + boxW - 10, boxY + boxH - 8);
    ctx.textAlign = 'left';
  }

  // Line indicator
  ctx.fillStyle = '#5a504060';
  ctx.font = '8px monospace';
  ctx.fillText(`${lineIndex + 1}/${npc.dialogue.length}`, boxX + 14, boxY + boxH - 8);
}

export function drawCutscene(ctx: CanvasRenderingContext2D, w: number, h: number, cutsceneId: string, lineIndex: number) {
  const cs = cutsceneTriggers.find(c => c.id === cutsceneId);
  if (!cs) return;

  // Dark overlay
  ctx.fillStyle = '#000000cc';
  ctx.fillRect(0, 0, w, h);

  // Cinematic bars
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, w, 50);
  ctx.fillRect(0, h - 50, w, 50);

  // Render lines
  ctx.textAlign = 'center';
  const startY = h * 0.35;

  for (let i = 0; i <= lineIndex && i < cs.lines.length; i++) {
    const line = cs.lines[i];
    if (!line.text && !line.speaker) continue;

    if (line.speaker) {
      ctx.fillStyle = COLORS.gold;
      ctx.font = 'italic 12px monospace';
    } else {
      ctx.fillStyle = '#9a9080';
      ctx.font = '12px monospace';
    }

    ctx.fillText(line.text, w / 2, startY + i * 22);
  }

  // Continue
  if (lineIndex >= cs.lines.length - 1) {
    const blink = Math.sin(Date.now() * 0.004) > 0;
    if (blink) {
      ctx.fillStyle = COLORS.gold;
      ctx.font = '11px monospace';
      ctx.fillText('CONTINUE', w / 2, h - 65);
    }
  }

  ctx.textAlign = 'left';
}

export function drawEnding(ctx: CanvasRenderingContext2D, w: number, h: number, lineIndex: number, score: number) {
  // Background
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#040608');
  grad.addColorStop(0.5, '#0a1420');
  grad.addColorStop(1, '#040608');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Golden glow
  const glow = ctx.createRadialGradient(w / 2, h * 0.3, 0, w / 2, h * 0.3, 100);
  glow.addColorStop(0, '#daa52010');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, w, h);

  ctx.textAlign = 'center';
  const startY = 50;
  const lineHeight = 20;

  for (let i = 0; i <= lineIndex && i < endingLines.length; i++) {
    const line = endingLines[i];
    if (!line.text) continue;

    if (line.text === 'THE END') {
      ctx.fillStyle = COLORS.gold;
      ctx.font = 'bold 22px monospace';
      ctx.fillText(line.text, w / 2, startY + i * lineHeight + 10);
    } else if (line.speaker) {
      ctx.fillStyle = COLORS.gold;
      ctx.font = 'italic 11px monospace';
      ctx.fillText(line.text, w / 2, startY + i * lineHeight);
    } else {
      ctx.fillStyle = '#8a8070';
      ctx.font = '11px monospace';
      ctx.fillText(line.text, w / 2, startY + i * lineHeight);
    }
  }

  // Score
  if (lineIndex >= endingLines.length - 1) {
    ctx.fillStyle = COLORS.gold;
    ctx.font = '13px monospace';
    ctx.fillText(`ORENS COLLECTED: ${score}`, w / 2, h - 80);

    const blink = Math.sin(Date.now() * 0.004) > 0;
    if (blink) {
      ctx.fillStyle = '#d4c5a9';
      ctx.font = '12px monospace';
      ctx.fillText('PRESS ANY KEY TO PLAY AGAIN', w / 2, h - 50);
    }
  }

  ctx.textAlign = 'left';
}

export function drawNpc(ctx: CanvasRenderingContext2D, npc: NpcData, spoken: boolean) {
  const x = npc.x;
  const y = npc.y;

  if (npc.type === 'soldier') {
    // Wounded soldier sitting against wall
    ctx.fillStyle = spoken ? '#5a504050' : '#6a6050';
    // Body
    ctx.fillRect(x - 6, y - 20, 12, 16);
    // Head
    ctx.fillStyle = '#c0b0a0';
    ctx.fillRect(x - 4, y - 28, 8, 9);
    // Helmet
    ctx.fillStyle = '#555';
    ctx.fillRect(x - 5, y - 30, 10, 5);
    // Legs (sitting)
    ctx.fillStyle = spoken ? '#4a403850' : '#5a5040';
    ctx.fillRect(x - 8, y - 4, 16, 4);
    // Blood stain
    if (!spoken) {
      ctx.fillStyle = '#8b000050';
      ctx.fillRect(x + 2, y - 16, 5, 8);
    }
  } else if (npc.type === 'merchant') {
    // Merchant with a pack
    ctx.fillStyle = spoken ? '#5a504050' : '#6b5a3a';
    // Body
    ctx.fillRect(x - 6, y - 26, 12, 18);
    // Head
    ctx.fillStyle = '#c0b0a0';
    ctx.fillRect(x - 4, y - 34, 8, 9);
    // Hat
    ctx.fillStyle = '#4a3a2a';
    ctx.fillRect(x - 6, y - 36, 12, 4);
    // Pack on back
    ctx.fillStyle = '#5a4a30';
    ctx.fillRect(x - 9, y - 24, 5, 12);
    // Legs
    ctx.fillStyle = spoken ? '#4a403850' : '#5a4a30';
    ctx.fillRect(x - 5, y - 8, 4, 8);
    ctx.fillRect(x + 1, y - 8, 4, 8);
  } else {
    // Sorceress (Keira)
    ctx.fillStyle = spoken ? '#4a406050' : '#4a3a6a';
    // Dress
    ctx.fillRect(x - 7, y - 28, 14, 22);
    ctx.fillStyle = '#5a4a7a';
    ctx.fillRect(x - 5, y - 26, 10, 4);
    // Head
    ctx.fillStyle = '#e0d0c0';
    ctx.fillRect(x - 4, y - 36, 8, 9);
    // Hair (blonde)
    ctx.fillStyle = '#d4b870';
    ctx.fillRect(x - 5, y - 38, 10, 5);
    ctx.fillRect(x + 4, y - 36, 3, 12);
    ctx.fillRect(x - 7, y - 36, 3, 10);
    // Magic glow
    if (!spoken) {
      const time = Date.now() * 0.003;
      ctx.globalAlpha = 0.3 + Math.sin(time) * 0.15;
      ctx.fillStyle = '#8a6aff';
      ctx.beginPath();
      ctx.arc(x, y - 24, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    // Legs
    ctx.fillStyle = '#3a2a4a';
    ctx.fillRect(x - 4, y - 6, 3, 6);
    ctx.fillRect(x + 1, y - 6, 3, 6);
  }

  // Interaction indicator (if not spoken)
  if (!spoken) {
    const bob = Math.sin(Date.now() * 0.004) * 3;
    ctx.fillStyle = COLORS.gold;
    ctx.font = 'bold 12px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('!', x, y - 44 + bob);
    ctx.textAlign = 'left';
  }
}

